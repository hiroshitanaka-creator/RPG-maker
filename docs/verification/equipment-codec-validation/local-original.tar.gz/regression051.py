import sys,json,hashlib,subprocess,pathlib
from qa051 import ROOT,REPO,OUT,GODOT,run
QA=ROOT/'qa-fixed051'
sha=(OUT/'fixed051-sha.txt').read_text().strip()
run('qa-fixed-clone',['git','clone','--shared','--no-checkout',REPO,QA],600,cwd=ROOT)
run('qa-fixed-checkout',['git','checkout','--detach',sha],60,cwd=QA)
run('fixed-frozen-before',[sys.executable,'tools/check_frozen_files.py'],30,cwd=QA)
run('fixed-import',[GODOT,'--headless','--editor','--import','--quit'],600,cwd=QA)
run('fixed-codec',[GODOT,'--headless','--path','.', '--script','res://tools/check_equipment_save_codec.gd'],120,cwd=QA,extra={'EQUIPMENT_CODEC_EVIDENCE':str(OUT/'fixed051')})
(OUT/'fixed051/codec.log').write_bytes((OUT/'fixed-codec.log').read_bytes())
run('core',[GODOT,'--headless','--path','.', '--script','res://tools/check_equipment_rules.gd'],240,cwd=QA)
run('s1',[GODOT,'--headless','--path','.', '--script','res://tools/check_equipment_save_migration.gd'],120,cwd=QA)
run('legacy',[GODOT,'--headless','--path','.', '--script','res://tools/fixtures/equipment-save/legacy_equivalence.gd'],120,cwd=QA,extra={'RPG_LEGACY_EQ_OUTPUT':str(OUT/'legacy-latest.json')})
run('locked',[sys.executable,'tools/run_locked_checks.py'],2450,cwd=QA)
run('assets',[sys.executable,'tools/validate_assets.py','--strict'],120,cwd=QA)
run('fixed-frozen-after',[sys.executable,'tools/check_frozen_files.py'],30,cwd=QA)
old=ROOT.parent/'task/evidence050/legacy-latest.json';new=OUT/'legacy-latest.json'
assert new.read_bytes()==old.read_bytes()
(OUT/'legacy-comparison.json').write_text(json.dumps({'fixed049_legacy_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'latest_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'all_bytes_equal':True,'fixed051_sha':sha},indent=2),encoding='utf8')
print('regression finished',sha,flush=True)
