import json,pathlib,hashlib,importlib.util
from qa051 import REPO,QA,OUT
def load(p):return json.loads(p.read_bytes())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[];executions={};results={}
for profile,sha,case_count,conditions,propagation in [('fixed049','99e9d03d4e095b4627b510efd4806f82276617c9',112,723,13),('fixed051','d813723b3acb2c77658317e7303c83f02f957a5b',154,975,18),('latest','361009af03205c969ced2b33495444df2882c655',154,975,18)]:
    root=OUT/'ci-artifacts'/profile
    output=root/'results';e=load(output/'execution.json');executions[profile]=e
    assert e['source_sha']==sha and e['profile']==profile and e['status']=='PASS'
    assert e['case_count']==case_count and e['checks']==conditions and len(e['propagation'])==propagation
    assert all(x['expected_exit']==x['observed_exit'] for x in e['propagation'])
    assert e['engine_sha256']=='8d106cbe6144c2dc7e881d61d2429c1a8a76e6b22ef48bd5e48dcf934953f71e'
    assert [r['name'] for r in e['commands']]==['version','frozen-before','import','codec','frozen-after']
    assert all(r['exit_code']==0 and not r['timed_out'] and r['seconds']<=r['budget_seconds'] and digest(output/(r['name']+'.log'))==r['log_sha256'] for r in e['commands'])
    assert [r['budget_seconds'] for r in e['commands']]==[30,30,600,120,30]
    manifest=load(output/'sha256.json')
    for file,expected in manifest.items():assert digest(output/file)==expected,file
    producer=load(output/'codec.json');results[profile]=producer
    module=QA/'tools/fixtures/equipment-save-codec/run_ci.py' if profile=='fixed049' else REPO/'tools/fixtures/equipment-save-codec/run_ci.py'
    spec=importlib.util.spec_from_file_location(profile,module);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    m.validate(QA if profile=='fixed049' else REPO,output)
    if profile!='fixed049':
        assert e['scope_sha']=='99e9d03d4e095b4627b510efd4806f82276617c9' and e['implementation_sha']=='d813723b3acb2c77658317e7303c83f02f957a5b'
        assert len(e['scope_propagation'])==2 and all(x['expected_exit']==x['observed_exit'] for x in e['scope_propagation'])
    checks.append({'profile':profile,'source_sha':sha,'case_count':case_count,'checks':conditions,'propagation':propagation,'manifest_entries':len(manifest),'manifest_all_hash_equal':True,'commands':e['commands'],'codec_sha256':digest(output/'codec.json'),'execution_sha256':digest(output/'execution.json')})
old=load(REPO/'docs/verification/equipment-save-codec/fixed049/codec.json')
assert results['fixed049']==old
assert results['fixed051']==results['latest']
assert executions['fixed051']['source_files']==executions['latest']['source_files']
assert executions['fixed049']['scope_changes']==executions['latest']['scope_changes']
assert results['fixed051']['cases'][:112]==old['cases']
for before,after in zip(old['observations'],results['fixed051']['observations'][:112]):
    assert before=={k:v for k,v in after.items() if k not in ['document_bytes','document_sha256']},before['case']
value={'run_id':37714045106,'artifacts':checks,'fixed049_all_results_equal_original':True,'fixed051_latest_all_results_equal':True,'fixed051_latest_source_files_equal':True,'original_112_observations_equal':True,'original_scope_predicate_results_equal':True}
(OUT/'ci-artifact-check.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(value,ensure_ascii=False,indent=2))
