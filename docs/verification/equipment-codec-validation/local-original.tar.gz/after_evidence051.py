import sys,os,json,importlib.util
from qa051 import ROOT,REPO,QA,OUT,run
p=REPO/'tools/fixtures/equipment-save-codec/run_ci.py'
spec=importlib.util.spec_from_file_location('repaired',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
output=OUT/'after-codec-final'
run('after-validate',[sys.executable,p,'--validate-only','--checkout',REPO,'--output',output],30,cwd=REPO)
os.environ['PYTHONUTF8']='1'
rows=m.self_test(REPO,output)
(OUT/'after-propagation.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
scope=m.scope_self_test(REPO,OUT)
(OUT/'after-scope.json').write_text(json.dumps(scope,ensure_ascii=False,indent=2),encoding='utf8')
print('propagation',len(rows),'scope',scope)
# 112原観測は追加されたproducer証拠fieldを除いて全値を照合。
before=json.loads((OUT/'before-codec/codec.json').read_bytes())
after=json.loads((output/'codec.json').read_bytes())
assert after['original_case_count']==112 and after['original_checks']==723
assert after['cases'][:112]==before['cases']
for a,b in zip(before['observations'],after['observations'][:112]):
    assert a=={k:v for k,v in b.items() if k not in ['document_bytes','document_sha256']},a['case']
(OUT/'original-preserved.json').write_text(json.dumps({'case_count':112,'checks':723,'case_order_equal':True,'all_original_observations_equal':True,'original_expectations_sha256':m.digest((REPO/'tools/fixtures/equipment-save-codec/expectations.json').read_bytes())},indent=2),encoding='utf8')
