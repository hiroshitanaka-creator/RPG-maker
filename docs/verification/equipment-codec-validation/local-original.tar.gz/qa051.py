import os, sys, subprocess, json, time, hashlib, pathlib, shutil, re
ROOT=pathlib.Path(__file__).resolve().parent
REPO=ROOT/'impl051'
QA=ROOT/'fix051'
OUT=ROOT/'evidence051'
GODOT=ROOT/'qa-bin'/'godot.exe'
OUT.mkdir(exist_ok=True)
GODOT.parent.mkdir(exist_ok=True)
if not GODOT.exists(): shutil.copy2(ROOT.parent/'task/qa-bin/godot.exe',GODOT)
env=os.environ.copy();env['PYTHONUTF8']='1'
for key in ['APPDATA','LOCALAPPDATA','USERPROFILE','HOME','XDG_DATA_HOME','XDG_CACHE_HOME','XDG_CONFIG_HOME']:
    p=ROOT/'qa-profile'/key;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env['PATH']=str(GODOT.parent)+os.pathsep+str(pathlib.Path(sys.executable).parent)+os.pathsep+env['PATH']
def run(label,args,limit=120,cwd=QA,extra=None):
    e=env.copy();e.update(extra or {});start=time.monotonic()
    try:
        p=subprocess.run([str(a) for a in args],cwd=cwd,env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=limit)
        code,raw=p.returncode,p.stdout
    except subprocess.TimeoutExpired as x:code,raw=124,(x.stdout or b'')+b'\nTIMEOUT'
    (OUT/(label+'.log')).write_bytes(raw)
    row={'label':label,'argv':[str(a) for a in args],'cwd':str(cwd),'limit':limit,'seconds':time.monotonic()-start,'exit':code,'sha256':hashlib.sha256(raw).hexdigest(),'bad_log':bool(re.search(rb'SCRIPT ERROR|ERROR:|WARNING:|Parse Error',raw))}
    with (OUT/'commands.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
    print(json.dumps(row,ensure_ascii=False),flush=True);print(raw.decode('utf8',errors='replace')[-2000:],flush=True)
    return code
if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='init':
        report=(REPO/'docs/tasks/reports/050-review-equipment-save-codec.md').read_text(encoding='utf8')
        probe=report.split('```gdscript\n',1)[1].split('```',1)[0]
        (QA/'independent050.gd').write_text(probe,encoding='utf8')
        run('version',[GODOT,'--version'],30)
        run('import-before',[GODOT,'--headless','--editor','--import','--quit'],600)
    elif mode=='before':
        for name in ['metadata','context','relocation','progress','shape','catalog']:
            run('before-'+name,[GODOT,'--headless','--path','.', '--script','res://independent050.gd','--',name],120)
        run('before-codec',[GODOT,'--headless','--path','.', '--script','res://tools/check_equipment_save_codec.gd'],120,extra={'EQUIPMENT_CODEC_EVIDENCE':str(OUT/'before-codec')})
        shutil.copyfile(OUT/'before-codec.log',OUT/'before-codec/codec.log')
    elif mode=='after':
        run('import-after',[GODOT,'--headless','--editor','--import','--quit'],600,cwd=REPO)
        for name in ['metadata','context','relocation','progress','shape','catalog']:
            run('after-'+name,[GODOT,'--headless','--path',str(REPO),'--script',str(QA/'independent050.gd'),'--',name],120,cwd=REPO)
        run('after-codec',[GODOT,'--headless','--path','.', '--script','res://tools/check_equipment_save_codec.gd'],120,cwd=REPO,extra={'EQUIPMENT_CODEC_EVIDENCE':str(OUT/'after-codec')})
        shutil.copyfile(OUT/'after-codec.log',OUT/'after-codec/codec.log')
