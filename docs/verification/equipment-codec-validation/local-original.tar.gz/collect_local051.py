import pathlib,shutil,json,hashlib,subprocess,importlib.util,os
from qa051 import ROOT,REPO,OUT
qa=ROOT/'qa-fixed051'
shutil.copyfile(qa/'docs/verification/scope-lock-current.json',OUT/'scope-lock-current.json')
logs=sorted((qa/'.tools/verification').glob('current-*'))
shutil.copytree(logs[-1],OUT/'R-logs')
shutil.copyfile(ROOT/'fix051/independent050.gd',OUT/'independent050.gd')
for name in ['qa051.py','probe_evidence051.py','after_evidence051.py','regression051.py','audit051.py']:shutil.copyfile(ROOT/name,OUT/name)
cmds=[json.loads(line) for line in (OUT/'commands.jsonl').read_text(encoding='utf8').splitlines()]
passing=[r for r in cmds if r['label'] in ['version','import-before','before-codec','after-metadata','after-context','after-relocation','after-progress','after-shape','after-catalog','after-codec-final','after-validate','fixed-frozen-before','fixed-import','fixed-codec','core','s1','legacy','locked','assets','fixed-frozen-after']]
assert len(passing)==20 and all(r['exit']==0 and not r['bad_log'] for r in passing)
r=json.loads((OUT/'scope-lock-current.json').read_bytes())
assert len(r['results'])==8 and all(x['status']=='PASS' and x['tests_ran'] and not x['parser_failed'] and not x['timed_out'] for x in r['results'])
# 原049コードは登録時点でも同一blob（文書状態は別）。
diff=subprocess.check_output(['git','diff','--name-status','99e9d03d4e095b4627b510efd4806f82276617c9','329567e79d2a6ace2e4c3b10b729f1e76cd27071','--','scripts','tools','data'],cwd=REPO).decode();assert not diff,diff
p=REPO/'tools/fixtures/equipment-save-codec/run_ci.py'
spec=importlib.util.spec_from_file_location('m',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
result=m.validate(qa,OUT/'fixed051')
assert result==json.loads((OUT/'after-codec-final/codec.json').read_bytes())
all_changes=subprocess.check_output(['git','diff','--name-status','329567e79d2a6ace2e4c3b10b729f1e76cd27071','HEAD'],cwd=REPO).decode().splitlines()
summary={'fixed051_sha':(OUT/'fixed051-sha.txt').read_text().strip(),'fixed049_code_to_registration_diff':[],'passed_commands':passing,'R_count':8,'protected_count':26,'case_count':154,'checks':975,'original_case_count':112,'original_checks':723,'additional_case_count':42,'additional_checks':252,'propagation_original_count':13,'propagation_repaired_count':18,'scope_propagation_count':2,'fixed_vs_working_all_codec_results_equal':True,'all_changes':all_changes}
(OUT/'local-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in summary.items() if k!='passed_commands'},ensure_ascii=False))
