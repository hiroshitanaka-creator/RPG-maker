import sys, pathlib, importlib.util, shutil, subprocess, json, os
from qa051 import ROOT,REPO,QA,OUT,env,run
baseline=QA/'tools/fixtures/equipment-save-codec/run_ci.py'
spec=importlib.util.spec_from_file_location('original',baseline);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
changed=subprocess.check_output(['git','-C',str(REPO),'diff','--name-status',m.BASE,'329567e79d2a6ace2e4c3b10b729f1e76cd27071']).decode().splitlines()
allowed=set(m.FILES)|{'docs/tasks/049-equipment-save-codec.md','docs/tasks/reports/049-equipment-save-codec.md','docs/decision-log.md','.github/workflows/equipment-codec.yml'}
errors=[]
for line in changed:
    status,path=line.split('\t',1)
    if not (status in ['A','M'] and (path in allowed or path.startswith(('tools/fixtures/equipment-save-codec/','docs/verification/equipment-save-codec/')) or (path.endswith('.uid') and path[:-4] in m.FILES))):errors.append('担当外差分:'+line)
(OUT/'before-scope.json').write_text(json.dumps({'source_sha':'329567e79d2a6ace2e4c3b10b729f1e76cd27071','original_scope_errors':errors,'changes':changed,'method':'原mainのscope判定を同じ定数と完全SHAに適用。Linux専用main全体の実行ではない。'},ensure_ascii=False,indent=2),encoding='utf8')
print(errors)
original=OUT/'before-codec'
for name in ['control','checks-one','document-empty']:
    p=OUT/('before-forged-'+name);shutil.copytree(original,p)
    if name=='checks-one':
        d=json.loads((p/'codec.json').read_bytes());d['checks']=1
        (p/'codec.json').write_text(json.dumps(d,ensure_ascii=False),encoding='utf8')
        (p/'codec.log').write_text((p/'codec.log').read_text(encoding='utf8').replace('723条件','1条件'),encoding='utf8')
    if name=='document-empty':(p/'M09-new-typed/document.gdv').write_bytes(b'')
    run('before-forged-'+name,[sys.executable,baseline,'--validate-only','--checkout',QA,'--output',p],30)
# 原13件を別出力の実子exitで保持確認。
os.environ['PYTHONUTF8']='1'
rows=m.self_test(QA,original)
(OUT/'before-propagation.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
print('original propagation',len(rows))
