import pathlib,subprocess,json,hashlib
from qa051 import ROOT,REPO,OUT
base='329567e79d2a6ace2e4c3b10b729f1e76cd27071';fixed=(OUT/'fixed051-sha.txt').read_text().strip()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO).decode().strip()
head=git('rev-parse','HEAD')
preserved=['test','.scope-lock','assets','addons','data','world','scenes','scripts/combat','scripts/game/equipment_save_migration.gd','scripts/game/equipment_save_validation.gd','scripts/game/equipment_state_view.gd','scripts/game/game_session.gd','scripts/game/integrated_progression.gd','scripts/game/saved_document.gd','scripts/game/saved_value_types.gd','tools/check_equipment_rules.gd','tools/check_equipment_save_migration.gd','tools/check_equipment_validation.gd','tools/fixtures/equipment-save','tools/fixtures/equipment','.github/workflows/ci.yml','.github/workflows/equipment.yml','.github/workflows/region2-village-connections.yml','.github/workflows/legacy-campaign.yml','docs/verification/equipment-save-codec','docs/tasks/049-equipment-save-codec.md','docs/tasks/reports/049-equipment-save-codec.md','docs/tasks/reports/050-review-equipment-save-codec.md']
preserved=[p for p in preserved if (REPO/p).exists()]+['.github/workflows/equipment-save.yml']
differences=git('diff','--name-status',base,head,'--',*preserved)
assert not differences,differences
source_diff=git('diff','--name-status',fixed,head,'--','scripts','tools','data');assert not source_diff,source_diff
all_changes=git('diff','--name-status',base,head).splitlines()
assert all(line[0]!='D' for line in all_changes)
doc_before=subprocess.check_output(['git','show',base+':docs/decision-log.md'],cwd=REPO)
doc_after=(REPO/'docs/decision-log.md').read_bytes()
assert doc_after.startswith(doc_before)
value={'registration_sha':base,'fixed051_sha':fixed,'head_sha':head,'preserved_paths':preserved,'preserved_differences':[],'fixed051_code_fixture_differences':[],'all_changes':all_changes,'decision_log_original_prefix_equal':True,'godot_windows_sha256':hashlib.sha256((ROOT/'qa-bin/godot.exe').read_bytes()).hexdigest(),'original_expectations_sha256':hashlib.sha256((REPO/'tools/fixtures/equipment-save-codec/expectations.json').read_bytes()).hexdigest()}
(OUT/'source-preservation.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(value,ensure_ascii=False,indent=2))
