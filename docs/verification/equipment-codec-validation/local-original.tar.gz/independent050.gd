extends SceneTree
const F=preload("res://tools/fixtures/equipment-save-codec/fixtures.gd")
const M=preload("res://scripts/game/equipment_save_migration.gd")
const V=preload("res://scripts/game/equipment_document_validation.gd")
const C=preload("res://scripts/game/equipment_save_codec.gd")
var s=GameSession.new()
var ctx:Dictionary
var checks=0
var failures=[]
func ck(ok:bool,label:String):
	checks+=1
	if not ok:failures.append(label)
func same(a:Variant,b:Variant)->bool:
	if typeof(a)!=typeof(b):return false
	if a is Dictionary:
		if a.size()!=b.size() or a.is_typed()!=b.is_typed():return false
		for key in a:
			if not b.has(key) or not same(a[key],b[key]):return false
		return true
	if a is Array:
		if a.size()!=b.size() or a.get_typed_builtin()!=b.get_typed_builtin():return false
		for i in range(a.size()):
			if not same(a[i],b[i]):return false
		return true
	return a==b
func emit(label:String,r:Dictionary):
	print("OBS ",label," ",JSON.stringify({"ok":r.get("ok"),"reason":r.get("reason_code"),"errors":r.get("errors"),"document":r.has("document"),"caps":r.get("caps_changes",[])}))
func base(region=true):
	var p=M.new().plan(F.region() if region else F.base(),"a".repeat(64),ctx)
	return V.prepare_candidate(p.candidate_document,ctx).document
func metadata():
	var d=base();d["_play_session"]=F.metrics();d=F.typed(d)
	ck(C.encode_candidate(d,ctx).ok,"valid metadata control")
	for kind in ["null","version","missing","duplicate","builtin","unknown","mismatch"]:
		var b=d.duplicate(true)
		match kind:
			"null":b._saved_value_types=null
			"version":b._saved_value_types.version=99
			"missing":b._saved_value_types.floats.append(["missing"])
			"duplicate":b._saved_value_types.floats.append(b._saved_value_types.floats[0].duplicate())
			"builtin":b._saved_value_types.arrays[0].builtin=TYPE_OBJECT
			"unknown":b._saved_value_types["extra"]=1
			"mismatch":b._saved_value_types.floats=[]
		var before=var_to_bytes(b)
		var enc=C.encode_candidate(b,ctx);emit("encode-"+kind,enc)
		var prep=V.prepare_candidate(b,ctx);emit("prepare-"+kind,prep)
		ck(not enc.ok,"encode rejects "+kind)
		ck(not prep.ok and not prep.has("document"),"prepare rejects "+kind)
		ck(var_to_bytes(b)==before,"metadata input unchanged "+kind)
func progress():
	var d=base()
	var before=var_to_bytes(d)
	var p=d.duplicate(true)
	p.inventory.potion+=1;p.first_region.coins+=1
	p.first_region.reserve[0].jp["warrior"]=3
	p.first_region.reserve[0].integrated.mastery.counts["warrior"]=1
	p.first_region.reserve[0].hp=0
	p.party.append(p.first_region.reserve.pop_front())
	p=F.typed(p)
	var r=C.encode_candidate(p,ctx);emit("progress-and-recruit",r)
	ck(r.ok,"legal progress and reserve recruit")
	ck(not V.compare_migration(F.region(),p,"a".repeat(64),ctx).is_empty(),"migration diff separately rejects progress")
	ck(var_to_bytes(d)==before,"original unchanged")
	if r.ok:
		var q=C.decode_source(r.bytes,ctx)
		ck(q.ok and same(q.document,r.document),"all values types order roundtrip")
		ck(q.document.party[1].hp==0,"reserve death no revive")
	var g=d.duplicate(true);g.progress_flags["job_change_unlocked"]=true
	var gc=ctx.duplicate();gc["job_change_unlocked"]=true
	var grant=M.new().grant_common(g,F.region(),"a".repeat(64),gc)
	ck(grant.ok,"pure common grant")
	if grant.ok:
		var prepared=V.prepare_candidate(grant.candidate_document,ctx)
		emit("common-grant",prepared)
		ck(prepared.ok and prepared.document.equipment_stock.instances.size()==22,"common grant 12 to22")
		var raw=C.encode_candidate(prepared.document,ctx)
		ck(raw.ok,"common grant encodes")
	var future=d.duplicate(true)
	future.equipment_stock.instances["future_example"]="practice_blade"
	future.equipment_stock.bag.append("future_example")
	emit("future-acquisition-outside-S2",C.encode_candidate(future,ctx))
func shape():
	for key in ["party","progress_flags","inventory","residents"]:
		for value in [null,1,[],{}]:
			var d=F.region()
			if key=="residents":d.overworld["residents"]=value
			else:d[key]=value
			var raw=JSON.stringify(d).to_utf8_buffer()
			print("BEGIN shape ",key," ",JSON.stringify(value))
			var r=C.decode_source(raw,ctx);emit(key,r)
			var valid_control=value is Dictionary and value.is_empty() and key in ["progress_flags","residents"]
			ck(r.get("ok",false) if valid_control else (not r.get("ok",false) and not r.has("document") and not r.get("errors",[]).is_empty()),"shape outcome "+key+str(value))
			print("END shape ",key)
func catalog():
	var data=JSON.parse_string(FileAccess.get_file_as_string("res://data/equipment_abilities.json"))
	for key in ["id","kind","target","cost","power","hits","description"]:
		for value in [null,[],{},true,"wrong"]:
			var c=BattleCatalog.new();var bad=data.duplicate(true);bad.abilities[0][key]=value
			print("BEGIN catalog ",key," ",JSON.stringify(value))
			c._load_equipment_document(bad)
			ck(c.equipment_errors.is_empty() if key=="description" and value is String else (not c.equipment_errors.is_empty() and c.equipment_context_abilities().is_empty()),"catalog outcome "+key+str(value))
			print("END catalog ",key)
func relocation():
	for key in ["party","residents"]:
		var d=F.region();d.overworld.room=1;d.overworld.cell=[1,1]
		if key=="party":d.party=null
		else:d.overworld["residents"]=null
		print("BEGIN relocation ",key)
		var r=C.decode_source(JSON.stringify(d).to_utf8_buffer(),ctx);emit("relocation-"+key,r)
		ck(not r.get("ok",false) and not r.has("document"),"relocation malformed refuses "+key)
		print("END relocation ",key)
func context():
	var d=base()
	for mode in ["missing-session","missing-abilities","null-catalog","catalog-errors"]:
		var ns=GameSession.new();ns.new_game()
		var c={"legacy_session":ns,"abilities":ns.catalog.equipment_context_abilities()}
		match mode:
			"missing-session":c.erase("legacy_session")
			"missing-abilities":c.erase("abilities")
			"null-catalog":ns.catalog=null
			"catalog-errors":ns.catalog.equipment_errors.append("fixture invalid")
		print("BEGIN context ",mode)
		var r=C.encode_candidate(d,c);emit(mode,r)
		ck(not r.get("ok",false) and not r.has("document"),"context rejects "+mode)
		print("END context ",mode)
func _initialize():
	print("QA_USER_DIR ",OS.get_user_data_dir())
	s.new_game();ctx={"legacy_session":s,"abilities":s.catalog.equipment_context_abilities()}
	var before=var_to_bytes(s.export_state());var metrics=var_to_bytes(s.play_metrics.snapshot())
	var mode=OS.get_cmdline_user_args()[0]
	call(mode)
	ck(before==var_to_bytes(s.export_state()) and metrics==var_to_bytes(s.play_metrics.snapshot()),"live state metrics history unchanged")
	print("REVIEW050 ",JSON.stringify({"mode":mode,"checks":checks,"failures":failures}))
	quit(0 if failures.is_empty() else 1)
