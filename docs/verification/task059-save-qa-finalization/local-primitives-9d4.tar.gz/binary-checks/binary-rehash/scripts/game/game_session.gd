class_name GameSession
extends RefCounted

const MONSTER_BATTLE_EROSION := 3
const MONSTER_SKILL_EROSION := 1

var catalog: BattleCatalog
var jobs: Dictionary = {}
var abilities: Dictionary = {}
var enemy_definitions: Dictionary = {}
var errors: Array[String] = []
var play_metrics := PlaySessionMetrics.new()
var _archive: PlaythroughArchive
var job_progression: Dictionary = {}

var _state: Dictionary = {}
var _battle: BattleState
var _battle_enemy_ids: Array[String] = []
var _claimed: bool = true
var _field_battle: bool = false
var _story_wave_step: int = -1
var _story_wave_number: int = 0
var _expedition_battle_stage: int = -1
var _world_battle_id: String = ""
var _pending_region_recruit := ""
var _pending_region_audience := false
var _pending_region_travel := ""
var _region_story: Dictionary = {}


func _init() -> void:
	catalog = BattleCatalog.new()
	jobs = catalog.jobs
	abilities = catalog.abilities
	enemy_definitions = catalog.enemies
	job_progression = JSON.parse_string(FileAccess.get_file_as_string("res://data/job_progression_v1.json"))
	errors.assign(catalog.errors)
	errors.append_array(StoryCampaign.audit())
	errors.append_array(ExplorationSites.audit(abilities,jobs))
	errors.append_array(CampaignContent.audit(enemy_definitions))
	if LongCampaign.enabled():errors.append_array(LongCampaign.audit(abilities,enemy_definitions))
	if enemy_definitions.size() != 36:
		errors.append("敵データは既存30種類と第2地方の海3種類・地上3種類、計36種類です。")
	for index in range(StoryCampaign.total_steps()):
		var step := StoryCampaign.step(index)
		for wave in StoryCampaign.battle_waves(step):
			if not wave is Array or wave.is_empty() or wave.size() > 3:
				errors.append("本編の敵編成は1〜3体です。")
				continue
			for identifier in wave:
				if not enemy_definitions.has(identifier):
					errors.append("本編の敵編成に未知の敵があります。")
	var keeper_learned: Array[String] = []
	keeper_learned.assign(StoryCampaign.data().get("keeper_learned",[]))
	var keeper_equipped: Array[String] = []
	keeper_equipped.assign(StoryCampaign.data().get("keeper_loadout",[]))
	for identifier in keeper_learned:
		if not abilities.has(identifier):
			errors.append("番人の習得記録に未知の技があります。")
	if not Loadout.validate(keeper_learned,keeper_equipped,Loadout.capacity(false,true)).is_empty():
		errors.append("番人の装着記録が当時の三枠と一致しません。")
	var humans := 0
	var monsters := 0
	for definition in jobs.values():
		if not definition.has_all(["id", "name", "type", "stat_growth", "abilities", "mastery_cost"]):
			errors.append("職業の必須項目が不足しています。")
			continue
		if definition["type"] == "human":
			humans += 1
		elif definition["type"] == "monster":
			monsters += 1
	if humans != 12 or monsters != 8:
		errors.append("v1の職業数は人間12・モンスター8です。")


func new_game(party_size: int = 4) -> bool:
	if not errors.is_empty() or party_size < 3 or party_size > 4:
		return false
	_region_story.clear()
	if _archive != null and not _state.is_empty():
		_archive.lifetime.record_event("trial_closed",{"reason":"new_game"})
		close_recording()
	var starts := ["warrior", "martial_artist", "priest", "mage"]
	var cast: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/cast_v1.json"))
	var party: Array = []
	for i in range(party_size):
		var job: Dictionary = jobs[starts[i]]
		party.append({
			"id": "pc_%02d" % (i + 1), "name": cast["actors"]["pc_%02d" % (i+1)]["name"],
			"job_id": starts[i], "last_human_job": starts[i], "jp": {},
			"mastered_jobs": [], "learned_abilities": [], "equipped_abilities": [],
			"unlocked_jobs": [],
			"monster_form": "", "erosion": 0, "irreversible": false,
			"hp": int(job["stats"]["hp"]), "max_hp": int(job["stats"]["hp"]),
			"mp": int(job["stats"]["mp"]), "max_mp": int(job["stats"]["mp"])
		})
	for actor in party:actor["integrated"]=IntegratedProgression.initial_actor()
	play_metrics = PlaySessionMetrics.new()
	_state = {"format_version": 2, "party": party, "leader_id":"pc_01", "inventory": {"potion": 3},
		"progress_flags": {"chapter1_cleared": false, "midgame_slots": false},
		"field_battles": 0, "return_point": {}, "story_battle": {}, "content_revision":1, "expedition":{},
		"world": {"location": "town", "player_cell": [2, 4], "quest_step": 0}}
	_state["integrated"]=IntegratedProgression.initial_world()
	if LongCampaign.enabled():_state["progress_flags"]["long_campaign_enrolled"]=true
	_battle = null
	_world_battle_id = ""
	_claimed = true
	_field_battle = false
	_story_wave_step = -1
	_expedition_battle_stage = -1
	if _archive != null:
		_archive.start(play_metrics)
		flush_recording()
	return true


func export_state() -> Dictionary:
	return _state.duplicate(true)


func new_first_region() -> bool:
	if not new_game(4):return false
	_pending_region_recruit=""
	_pending_region_audience=false
	_pending_region_travel=""
	_state["first_region"] = {"version":1,"reserve":_state["party"].slice(1).duplicate(true),"coins":20}
	_state["party"] = [_state["party"][0]]
	_state["inventory"]["world_map"] = 1
	_state["overworld"] = {"active":true,"layer":"interior","node":"start_village","room":0,"cell":[],"facing":0,"transport":"walk","cleared":[],"opened":[],"entry_lock":""}
	FirstRegion.place(_state["overworld"],FirstRegion.data()["start"])
	return true


func first_region_intro_available() -> bool:
	return first_region_active() and _battle == null and _region_story.is_empty() and not party_defeated() and FirstRegionStory.needs_return(_state) and _state["overworld"]["node"] != "first_cave"

## 後続の会話はこの結果を先に確認する。未見の本文を既知の内容として返さない。
func require_first_region_intro() -> Dictionary:
	if FirstRegionStory.complete(_state):return {"kind":"ready"}
	return {"kind":"intro_required","available":first_region_intro_available(),"action":"ui_intro"}

func begin_first_region_intro() -> Dictionary:
	if not first_region_intro_available():return {}
	return _begin_first_region_story("catchup",{})

func _begin_first_region_story(context: String, resume: Dictionary) -> Dictionary:
	if not _region_story.is_empty():return {}
	var queue := FirstRegionStory.queue_for(_state,context)
	if queue.is_empty():return FirstRegionStory.data()["repeat"].duplicate(true).merged({"kind":"dialogue"})
	_region_story={"queue":queue,"page":0,"context":context,"resume":resume.duplicate(true)}
	return FirstRegionStory.dialogue(queue[0],context=="catchup")

func first_region_story_presentation() -> Dictionary:
	if _region_story.is_empty():return {}
	var identifier: String=_region_story["queue"][0]
	var dialogue := FirstRegionStory.dialogue(identifier,_region_story["context"]=="catchup")
	return FirstRegionStory.presentation(identifier,dialogue["scene_title"],int(_region_story["page"]))

## ページ順序と場面IDを照合する。最後の通常決定だけが完了フラグを確定する。
func confirm_first_region_story(identifier: String, page: int) -> Dictionary:
	if not first_region_active() or _battle != null or _region_story.is_empty():return {}
	if identifier != _region_story["queue"][0] or page != _region_story["page"]:return {}
	var entry := FirstRegionStory.scene(identifier)
	_region_story["page"] += 1
	if _region_story["page"] < entry["lines"].size():return {"kind":"story_page"}
	_state["progress_flags"][entry["flag"]]=true
	_region_story["queue"].pop_front()
	_region_story["page"]=0
	if not _region_story["queue"].is_empty():return FirstRegionStory.dialogue(_region_story["queue"][0],_region_story["context"]=="catchup")
	var resume: Dictionary=_region_story["resume"]
	_region_story.clear()
	if resume.get("kind")=="stairs":
		FirstRegion.place(_state["overworld"],resume["to"])
	elif resume.get("kind")=="interact":
		var result := interact_first_region()
		return {"kind":"moved"} if result.is_empty() else result
	return {"kind":"moved"}

func first_region_active() -> bool:
	return _state.has("first_region")


func first_region_walkable(cell: Vector2i) -> bool:
	return first_region_active() and FirstRegion.walkable(_state,cell)


func first_region_face(direction: Vector2i) -> void:
	if first_region_active():_state["overworld"]["facing"] = [Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT,Vector2i.UP].find(direction)


func move_first_region(cell: Vector2i) -> Dictionary:
	if not first_region_active() or _battle != null or party_defeated() or not _region_story.is_empty():return {}
	var result := FirstRegion.move(_state,cell)
	if not result.is_empty():play_metrics.mark("moved_cells")
	if result.get("kind")=="story_request":return _begin_first_region_story("return",{"kind":"stairs","to":FirstRegion.data()["stairs_up"]["to"]})
	return result

func advance_first_region_residents() -> bool:
	return first_region_active() and _battle == null and _region_story.is_empty() and FirstRegion.advance_residents(_state)

func use_first_region_potion(actor_id: String) -> bool:
	if not first_region_active() or _battle != null or int(_state["inventory"].get("potion",0))<=0:return false
	var member := _member(actor_id)
	if member.is_empty() or member["hp"]<=0 or member["hp"]>=member["max_hp"]:return false
	member["hp"]=mini(int(member["max_hp"]),int(member["hp"])+catalog.potion_healing)
	_state["inventory"]["potion"]-=1
	return true


func interact_first_region() -> Dictionary:
	if not first_region_active() or _battle != null or not _region_story.is_empty():return {}
	if _state["overworld"]["node"]=="start_village" and not _state["progress_flags"].get("gado_workshop_seen",false):
		return _begin_first_region_story("village",{"kind":"interact"})
	if FirstRegion.at(_state["overworld"],FirstRegion.data()["stairs_up"]["from"]) and FirstRegionStory.needs_return(_state):
		return _begin_first_region_story("return",{"kind":"stairs","to":FirstRegion.data()["stairs_up"]["to"]})
	if FirstRegionTravel.board_or_land(_state):return {"kind":"moved"}
	var state: Dictionary = _state["overworld"]
	var target: Vector2i = WorldExpedition.point(state["cell"])+[Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT,Vector2i.UP][state["facing"]]
	for event in FirstRegion.residents_for(_state):
		if event["kind"] == "recruit" and FirstRegion.joined(_state,event["actor"]):continue
		var event_position := FirstRegion.event_cell(_state,event)
		var direction: Vector2i = [Vector2i.DOWN,Vector2i.LEFT,Vector2i.RIGHT,Vector2i.UP][state["facing"]]
		# reach=2 は台1つ分、reach=3 は奥行き2マスの台の向こうまで話しかけられる。
		var across_counter := false
		for step in range(1,int(event.get("reach",1))):
			if event_position == target+direction*step:across_counter = true
		if event_position != target and event_position != WorldExpedition.point(state["cell"]) and not across_counter:continue
		if event["kind"]=="story":return _begin_first_region_story("encounter",{})
		FirstRegion.face_event(_state,event)
		match event["kind"]:
			"npc":
				if state["node"]=="first_port" and event["id"] in ["port_shrine","harbor_keeper"]:
					var travel := FirstRegionTravel.ensure(_state)
					if event["id"]=="port_shrine" and not travel["return_learned"]:
						_pending_region_travel="return"
						return {"kind":"dialogue","speaker":"祠の世話役","travel_lesson":"return","text":["帰り道も、旅の備えです。一度訪れた町へ戻る術をお教えしましょう。","名は『帰還の風』。仲間の誰でも、MPを2使えば唱えられます。洞窟や塔の中では使えません。","船で出かけているときも、船は港へ戻ります。どうか、無事に帰ってきてください。"]}
					if event["id"]=="harbor_keeper" and not travel["ship_owned"]:
						_pending_region_travel="ship"
						return {"kind":"dialogue","speaker":"荷受けの係","travel_lesson":"ship","text":["沿岸へ出るなら、あの桟橋の船を使っていい。乗り込む前に、荷物と仲間を確かめてくれ。","中央の桟橋の船のそばで、決定キーを押すと乗れる。港や浅瀬に着いたら、同じように降りられるよ。","海にも魔物はいる。遠出の前に、宿で休んでおくといい。"]}
				if event.get("tower_path",false) and _state["progress_flags"].get("mountain_path_open",false):
					return {"kind":"dialogue","speaker":event.get("label","兵士"),"text":event["after_text"]}
				if event.get("audience",false):
					if _state["progress_flags"].get("job_change_unlocked",false):
						return {"kind":"dialogue","speaker":"王","text":["仲間の役目を確かめ、準備を整えて進むがよい。北の森へ向かう許しは出してある。"]}
					if int(_state["inventory"].get("gate_pass",0))!=1:return {}
					_pending_region_audience=true
					return {"kind":"dialogue","audience":true,"speakers":["王","カイナ","王","側近","王"],"text":["ベルナの通行証を持っているのだな。洞窟から無事に戻ったと聞いた。","仲間に助けられました。先へ進む前に、もっと備えを整えたいんです。","よい心がけだ。城の教練で、各々の役目に合った修練を受けることを許そう。","メニューの編成から職業を変え、覚えた技を装着できます。上級の職は、さらに先の修練が必要です。","北の森へ向かう許しも出しておく。急がず、互いの力を確かめて進むがよい。"]}
				if event.get("after_errand","")=="haldo" and _state["first_region"].get("errands",{}).get("haldo")=="complete":
					return {"kind":"dialogue","speaker":event.get("label","村人"),"text":event["after_text"]}
				return {"kind":"dialogue","speaker":event.get("label","村人"),"text":event["text"]}
			"recruit":
				if event.has("requires_clear") and event["requires_clear"] not in state["cleared"]:
					return {"kind":"dialogue","speaker":"スイナ","text":["気をつけて。中央の翼獣が、こちらを見ているわ。まずは身を守りましょう。"]}
				# 塔の実装前の保存には4人目の待機データがない。加入時に初期状態を用意する。
				if event["actor"]=="pc_04" and not _state["first_region"]["reserve"].any(func(a:Dictionary)->bool:return a["id"]=="pc_04"):
					var initial := GameSession.new()
					if not initial.new_game(4):return {}
					_state["first_region"]["reserve"].append(initial.export_state()["party"][3])
				if event.get("join_on_last_line",false):
					_pending_region_recruit=event["actor"]
					if event["actor"]=="pc_03":
						if not _state["first_region"].has("errands"):_state["first_region"]["errands"]={}
						_state["first_region"]["errands"]["haldo"]="requested"
					return {"kind":"dialogue","speaker_actor":event["actor"],"text":event["text"],"speakers":event["speakers"],"join_actor":event["actor"],"line_actions":event.get("line_actions",[]),"line_prompts":event.get("line_prompts",[])}
				for actor in _state["first_region"]["reserve"]:
					if actor["id"] == event["actor"]:
						_state["party"].append(actor.duplicate(true))
						_state["first_region"]["reserve"].erase(actor)
						return {"kind":"dialogue","speaker":actor["name"],"speaker_actor":actor["id"],"text":event["text"]+[actor["name"]+"が仲間になった。"]}
				return {"kind":"dialogue","text":["準備ができたら出発しよう。"]}
			"rest":
				rest()
				return {"kind":"dialogue","speaker":event.get("label","宿の主人"),"sound":"heal","text":["宿で休み、HPとMPが回復しました。"]}
			"shop":
				return {"kind":"shop","text":event["text"]}
			"weapon_shop":
				return {"kind":"weapon_shop","text":event["text"]}
			"treasure":
				if event["id"] in state["opened"]:return {"kind":"dialogue","text":["宝箱は空です。"]}
				state["opened"].append(event["id"])
				_state["inventory"][event["item"]] = int(_state["inventory"].get(event["item"],0))+int(event["amount"])
				return {"kind":"dialogue","speaker":"宝箱","sound":"chest","text":["回復薬を%d個手に入れた。" % event["amount"]]}
	return {}

func finish_first_region_audience() -> bool:
	if not first_region_active() or not _pending_region_audience or _battle!=null:return false
	var location: Dictionary=_state["overworld"]
	if location["node"]!="first_castle" or location["room"]!=2 or int(_state["inventory"].get("gate_pass",0))!=1:return false
	_state["progress_flags"]["job_change_unlocked"]=true
	_state["progress_flags"]["castle_north_permission"]=true
	_pending_region_audience=false
	return true

func finish_first_region_travel(lesson: String) -> bool:
	if not first_region_active() or _battle!=null or lesson!=_pending_region_travel or lesson not in ["return","ship"]:return false
	var here: Dictionary=_state["overworld"]
	if here["node"]!="first_port" or here["room"]!=(5 if lesson=="return" else 7):return false
	var travel := FirstRegionTravel.ensure(_state)
	if lesson=="return":travel["return_learned"]=true
	else:
		travel["ship_owned"]=true
		travel["ship_cell"]=FirstRegionTravel.data()["docks"][0]["ship_cell"].duplicate()
	_pending_region_travel=""
	return true

func first_region_boarding_label() -> String:
	return FirstRegionTravel.boarding_label(_state) if first_region_active() and _battle==null else ""

func board_first_region_ship() -> bool:
	return first_region_active() and _battle==null and FirstRegionTravel.board_or_land(_state)

func cast_first_region_return(actor_id: String, destination: String) -> bool:
	return first_region_active() and _battle==null and FirstRegionTravel.return_to(_state,actor_id,destination)

func finish_first_region_recruit(actor_id: String) -> bool:
	if not first_region_active() or actor_id.is_empty() or actor_id!=_pending_region_recruit:return false
	if actor_id=="pc_04" and (_state["overworld"]["node"]!="first_forest_tower" or "forest_tower_boss" not in _state["overworld"]["cleared"]):return false
	if actor_id=="pc_03" and _state["first_region"].get("errands",{}).get("haldo")!="wrapped":return false
	for actor in _state["first_region"]["reserve"]:
		if actor["id"]!=actor_id:continue
		_state["party"].append(actor.duplicate(true))
		_state["first_region"]["reserve"].erase(actor)
		_pending_region_recruit=""
		if actor_id=="pc_03":_state["first_region"]["errands"]["haldo"]="complete"
		if actor_id=="pc_04":_state["progress_flags"]["mountain_path_open"]=true
		return true
	return false

func help_first_region_bandage(action: String) -> bool:
	if not first_region_active() or _pending_region_recruit!="pc_03":return false
	var stage: String=str(_state["first_region"].get("errands",{}).get("haldo",""))
	if action=="hold_bandage" and stage=="requested":
		_state["first_region"]["errands"]["haldo"]="holding"
		return true
	if action=="release_bandage" and stage=="holding":
		_state["first_region"]["errands"]["haldo"]="wrapped"
		return true
	return false


func buy_first_region_potion() -> bool:
	if not first_region_active() or _state["first_region"]["coins"] < 5:return false
	_state["first_region"]["coins"] -= 5
	_state["inventory"]["potion"] += 1
	return true


func buy_first_region_weapon() -> bool:
	if not first_region_active() or _state["first_region"]["coins"] < 15 or "iron_blade" in _state["integrated"]["armory"]:return false
	_state["first_region"]["coins"] -= 15
	_state["integrated"]["armory"].append("iron_blade")
	return true


func start_first_region_battle(event: Dictionary) -> BattleState:
	if not first_region_active() or event.get("kind") != "battle":return null
	var encounter := start_battle(event["enemies"],int(event["seed"]))
	if encounter == null:return null
	_world_battle_id = event["id"]
	if _world_battle_id == "first_boss":
		var foe: Combatant = encounter.living(Combatant.Team.ENEMY)[0]
		foe.display_name="水門の荒獣"
		for key in FirstRegion.data()["boss"]["stats"]:
			foe.set("max_hp" if key == "hp" else key,int(FirstRegion.data()["boss"]["stats"][key]))
		foe.hp = foe.max_hp
	return encounter


func current_encounter_id() -> String:
	return _world_battle_id if not _world_battle_id.is_empty() else "legacy_encounter"


func _member(actor_id: String) -> Dictionary:
	for actor in _state.get("party", []):
		if actor["id"] == actor_id:
			return actor
	return {}


func import_state(value: Dictionary) -> bool:
	if _battle != null:
		return false
	var normalized: Variant = _normalize_numbers(value)
	if not _valid_state(normalized):
		return false
	_state = normalized.duplicate(true)
	_region_story.clear()
	_pending_region_travel=""
	_pending_region_recruit=""
	_pending_region_audience=false
	_world_battle_id = ""
	_battle = null
	_claimed = true
	_field_battle = false
	_story_wave_step = -1
	_expedition_battle_stage = -1
	return true


func _valid_state(value: Dictionary) -> bool:
	return validate_state_common(value)


func validate_state_common(value: Dictionary, equipment_context: Dictionary = {}) -> bool:
	# S2内部検証専用。通常入口は空contextで旧契約を継続する。
	var equipment_mode := not equipment_context.is_empty()
	if value.get("format_version") not in [1,2] or not value.get("party") is Array:
		return false
	if value["format_version"]==2:
		if equipment_mode:
			if not IntegratedProgression.valid_world_common(value.get("integrated")):return false
		elif not IntegratedProgression.valid_world(value.get("integrated")):return false
	if value["format_version"]==1 and value.has("integrated"):return false
	var party: Array = value["party"]
	if party.size() < (1 if value.has("first_region") else 3) or party.size() > 4 or not value.get("inventory") is Dictionary or not value.get("progress_flags") is Dictionary or not value.get("world") is Dictionary:
		return false
	if not IntegratedCampaign.flags_valid(value):return false
	if not _valid_world(value["world"],value["progress_flags"]):
		return false
	if value.has("first_region") and not FirstRegion.valid(value):return false
	if value.has("overworld") and not value.has("first_region") and not WorldExpedition.valid(value["overworld"]):
		return false
	if value.has("overworld") and not value.has("first_region") and value["overworld"]["active"] and value["overworld"]["origin"] != value["world"]["location"]:
		return false
	for identifier in value["progress_flags"]:
		if not identifier is String or not value["progress_flags"][identifier] is bool:
			return false
	if not StoryCampaign.validate_flags(value["progress_flags"]):
		return false
	if not ExplorationSites.valid_flags(value["progress_flags"]):
		return false
	if not CampaignContent.valid_state(value):
		return false
	if value["progress_flags"].get("story_v1_cleared", false) and not StoryCampaign.all_resolved(value["progress_flags"]):
		return false
	if value["progress_flags"].get("story_v1_cleared",false) and value["progress_flags"].get("long_campaign_started",false) and not LongCampaign.all_cleared(value["progress_flags"]):return false
	var task: Variant = value.get("story_task", {})
	if not task is Dictionary:
		return false
	if not task.is_empty():
		if not task.get("id") is String or not task.get("step") is int or StoryCampaign.step(value["world"]["quest_step"]).get("kind") != "choice" or StoryCampaign.step(value["world"]["quest_step"], task).is_empty():
			return false
	if not value.get("field_battles", 0) is int or int(value.get("field_battles", 0)) < 0:
		return false
	var return_point: Variant = value.get("return_point", {})
	if not return_point is Dictionary:
		return false
	if not return_point.is_empty():
		if not _valid_world(return_point,value["progress_flags"]) or return_point["location"] == "town" or value["world"]["location"] != "town" or return_point["quest_step"] != value["world"]["quest_step"]:
			return false
	var active_world: Dictionary = value["world"] if return_point.is_empty() else return_point
	var active_step := StoryCampaign.step(active_world["quest_step"],task)
	if not value.get("expedition",{}).is_empty():
		active_step = CampaignContent.step(value["expedition"],value["progress_flags"])
	if not active_step.is_empty() and active_world["location"] != active_step["location"]:
		return false
	var progress: Variant = value.get("story_battle",{})
	if not progress is Dictionary:
		return false
	if not progress.is_empty():
		if not value.get("expedition",{}).is_empty():
			return false
		if not progress.get("step") is int or not progress.get("cleared") is int or progress["step"] != active_world["quest_step"] or active_step.get("kind") != "battle":
			return false
		if progress["cleared"] < 0 or progress["cleared"] > StoryCampaign.battle_waves(active_step).size():
			return false
	if not value["inventory"].get("potion") is int or value["inventory"]["potion"] < 0:
		return false
	var ids: Array[String] = []
	for item in party:
		if not item is Dictionary or not validate_actor_common(item,value["format_version"],value.get("integrated",{}),value["progress_flags"],equipment_context):
			return false
		if item["id"] in ids:return false
		ids.append(item["id"])
	if value.has("leader_id") and (not value["leader_id"] is String or not value["leader_id"] in ids):
		return false
	var team: Variant = value.get("gate_team", [])
	if not team is Array:
		return false
	if not team.is_empty() or StoryCampaign.stage(value["progress_flags"],"R03") == 2:
		if team.size() != 3:
			return false
		var assigned: Array = []
		for identifier in team:
			if not identifier is String or not identifier in ids or identifier in assigned:
				return false
			assigned.append(identifier)
	return true


func validate_legacy_actor(actor: Dictionary, format_version: int, world_integrated: Dictionary, flags: Dictionary) -> bool:
	return validate_actor_common(actor,format_version,world_integrated,flags)


func validate_actor_common(actor: Dictionary, format_version: int, world_integrated: Dictionary, flags: Dictionary, equipment_context: Dictionary = {}) -> bool:
	# 新旧で非装備条件を共有し、新版は全stateを明示する。
	var equipment_mode := not equipment_context.is_empty()
	var actor_abilities: Dictionary = equipment_context.get("abilities", abilities)
	var required := ["id", "name", "job_id", "last_human_job", "jp", "mastered_jobs", "learned_abilities", "equipped_abilities", "monster_form", "erosion", "irreversible", "hp", "max_hp", "mp", "max_mp"]
	if not actor.has_all(required):
		return false
	if not actor["id"] is String or actor["id"].is_empty() or not actor["name"] is String:
		return false
	if not jobs.has(actor["job_id"]) or not jobs.has(actor["last_human_job"]) or jobs[actor["last_human_job"]]["type"] != "human":
		return false
	if not actor["jp"] is Dictionary:
		return false
	if not actor.get("unlocked_jobs",[]) is Array:
		return false
	var unlocked: Array = []
	for identifier in actor.get("unlocked_jobs",[]):
		if not identifier is String or not job_progression["advanced"].has(identifier) or identifier in unlocked:
			return false
		unlocked.append(identifier)
	for job_id in actor["jp"]:
		if not jobs.has(job_id) or not actor["jp"][job_id] is int or actor["jp"][job_id] < 0:
			return false
	for field in ["mastered_jobs", "learned_abilities", "equipped_abilities"]:
		if not actor[field] is Array:
			return false
		var seen: Array = []
		for identifier in actor[field]:
			if not identifier is String or identifier in seen:
				return false
			seen.append(identifier)
			if field == "mastered_jobs":
				if not jobs.has(identifier) or int(actor["jp"].get(identifier, 0)) < IntegratedProgression.cost(jobs[identifier],format_version==2):
					return false
			elif not actor_abilities.has(identifier):
				return false
	if not actor["erosion"] is int or actor["erosion"] < 0 or actor["erosion"] > 100 or not actor["irreversible"] is bool:
		return false
	if actor["erosion"] >= 90 and not actor["irreversible"]:
		return false
	var form: Variant = actor["monster_form"]
	if not form is String or (not form.is_empty() and (not jobs.has(form) or jobs[form]["type"] != "monster" or not form in actor["mastered_jobs"])):
		return false
	if actor["irreversible"] and jobs[actor["job_id"]]["type"] == "human":
		return false
	for field in ["hp", "max_hp", "mp", "max_mp"]:
		if not actor[field] is int or actor[field] < 0:
			return false
	if format_version==2:
		if equipment_mode:
			if not IntegratedProgression.valid_actor_common(actor,jobs,actor_abilities):return false
		elif not IntegratedProgression.valid_actor(actor,jobs,abilities,world_integrated["armory"]):return false
	if format_version==2 and world_integrated.has("mastery_rules_version")!=JobMastery.active(actor):return false
	if format_version==1 and actor.has("integrated"):return false
	if not equipment_mode or not equipment_context.get("skip_caps",false):
		var computed := equipment_stats(actor,equipment_context.get("document",{})) if equipment_mode else _compute_stats(actor, true)
		if computed.is_empty():return false
		if actor["max_hp"] != computed["hp"] or actor["max_mp"] != computed["mp"] or actor["hp"] > actor["max_hp"] or actor["mp"] > actor["max_mp"]:
			return false
	var available: Array[String] = _available(actor)
	var equipped_ids: Array[String] = []
	equipped_ids.assign(actor["equipped_abilities"])
	var slots := Loadout.capacity(bool(flags.get("midgame_slots", false)), not form.is_empty())
	if not Loadout.validate(available, equipped_ids, slots).is_empty():
		return false
	return true


static func _valid_world(world: Dictionary, flags: Dictionary = {}) -> bool:
	if not world.has_all(["location", "player_cell", "quest_step"]):
		return false
	if not world["location"] is String or not ChapterOne.TITLES.has(world["location"]):
		return false
	if not world["quest_step"] is int or world["quest_step"] < 0 or world["quest_step"] > StoryCampaign.total_steps():
		return false
	var cell: Variant = world["player_cell"]
	if not str(world.get("section","")).is_empty():
		var section := CampaignContent.section(str(world["section"]))
		return section.get("location") == world["location"] and cell is Array and cell.size() == 2 and cell[0] is int and cell[1] is int and CampaignContent.is_walkable(world["section"],Vector2i(cell[0],cell[1]),flags)
	return cell is Array and cell.size() == 2 and cell[0] is int and cell[1] is int and ExplorationSites.is_walkable(world["location"], Vector2i(cell[0],cell[1]),flags)


static func _normalize_numbers(value: Variant) -> Variant:
	if value is Dictionary:
		var result: Dictionary = {}
		for key in value:
			result[key] = _normalize_numbers(value[key])
		return result
	if value is Array:
		var result: Array = []
		for item in value:
			result.append(_normalize_numbers(item))
		return result
	if value is float and value == floor(value):
		return int(value)
	return value


func change_job(actor_id: String, job_id: String) -> bool:
	# 状態適用の基礎API。通常の職業選択はchoose_jobで解放条件も確認する。
	if _battle != null or not jobs.has(job_id):
		return false
	var actor := _member(actor_id)
	if actor.is_empty() or (actor["irreversible"] and jobs[job_id]["type"] == "human"):
		return false
	var previous_job: String = actor["job_id"]
	actor["job_id"] = job_id
	if jobs[job_id]["type"] == "human":
		actor["last_human_job"] = job_id
	elif job_id in actor["mastered_jobs"]:
		actor["monster_form"] = job_id
		_learn_form(actor, job_id)
	_refresh_caps(actor)
	_reconcile_slots(actor)
	play_metrics.record_event("job_changed",{"actor":actor_id,"from":previous_job,"to":job_id})
	return true


func job_unlocked(actor_id: String, job_id: String) -> bool:
	if first_region_active() and not _state["progress_flags"].get("job_change_unlocked",false):return false
	var actor := _member(actor_id)
	if actor.is_empty() or not jobs.has(job_id):
		return false
	# 世界マップ型の解放時期だけを制限する。旧本編の職業条件は維持する。
	if first_region_active():
		if jobs[job_id]["type"]=="monster" and not _state["progress_flags"].get("monster_jobs_unlocked",false):return false
		if job_progression["advanced"].has(job_id) and not _state["progress_flags"].get("advanced_jobs_unlocked",false):return false
	# 過去の保存で既に使った職は取り上げない。
	if actor["job_id"] == job_id or int(actor["jp"].get(job_id,0)) > 0 or job_id in actor["mastered_jobs"] or job_id in actor.get("unlocked_jobs",[]):
		return true
	var rule: Dictionary = job_progression["advanced"].get(job_id,{})
	if rule.is_empty():
		return true
	for required in rule["masters"]:
		if required not in actor["mastered_jobs"]:
			return false
	return int(actor["erosion"]) >= int(rule["erosion"])


func choose_job(actor_id: String, job_id: String) -> bool:
	if not job_unlocked(actor_id,job_id) or not change_job(actor_id,job_id):
		return false
	_grant_job_unlocks(_member(actor_id))
	return true


func _grant_job_unlocks(actor: Dictionary) -> void:
	for identifier in job_progression["advanced"]:
		var rule: Dictionary = job_progression["advanced"][identifier]
		var met: bool = int(actor["erosion"]) >= int(rule["erosion"])
		for required in rule["masters"]:
			met = met and required in actor["mastered_jobs"]
		if met and identifier not in actor.get("unlocked_jobs",[]):
			if not actor.has("unlocked_jobs"):
				actor["unlocked_jobs"] = []
			actor["unlocked_jobs"].append(identifier)
			play_metrics.record_event("job_unlocked",{"actor":actor["id"],"job":identifier})


func slot_limit(actor_id: String) -> int:
	var actor := _member(actor_id)
	if actor.is_empty():
		return 0
	return Loadout.capacity(bool(_state["progress_flags"].get("midgame_slots", false)), not str(actor["monster_form"]).is_empty())


func _form_abilities() -> Array[String]:
	var result: Array[String] = []
	for job in jobs.values():
		if job["type"] == "monster":
			for identifier in job["monster_form"]["abilities"]:
				result.append(identifier)
	return result


func _available(actor: Dictionary) -> Array[String]:
	var result: Array[String] = []
	var only_in_form := _form_abilities()
	var current_form: String = actor["monster_form"]
	for identifier in actor["learned_abilities"]:
		if identifier in only_in_form:
			if current_form.is_empty() or not identifier in jobs[current_form]["monster_form"]["abilities"]:
				continue
		result.append(identifier)
	return result


func available_abilities(actor_id: String) -> Array[String]:
	var actor := _member(actor_id)
	return [] if actor.is_empty() else _available(actor)


func equip_ability(actor_id: String, ability_id: String) -> bool:
	if first_region_active() and not _state["progress_flags"].get("job_change_unlocked",false):return false
	if _battle != null:
		return false
	var actor := _member(actor_id)
	if actor.is_empty():
		return false
	var candidate: Array[String] = []
	candidate.assign(actor["equipped_abilities"])
	candidate.append(ability_id)
	if not Loadout.validate(_available(actor), candidate, slot_limit(actor_id)).is_empty():
		return false
	actor["equipped_abilities"] = candidate
	play_metrics.record_event("ability_equipped",{"actor":actor_id,"ability":ability_id})
	return true


func unequip_ability(actor_id: String, ability_id: String) -> bool:
	if _battle != null:
		return false
	var actor := _member(actor_id)
	if actor.is_empty() or not ability_id in actor["equipped_abilities"]:
		return false
	actor["equipped_abilities"].erase(ability_id)
	_reconcile_slots(actor)
	play_metrics.record_event("ability_unequipped",{"actor":actor_id,"ability":ability_id})
	return true


func _reconcile_slots(actor: Dictionary) -> void:
	var valid := _available(actor)
	var kept: Array[String] = []
	for identifier in actor["equipped_abilities"]:
		if identifier in valid and kept.size() < slot_limit(actor["id"]):
			kept.append(identifier)
	actor["equipped_abilities"] = kept
	if actor.has("integrated"):
		if "twin_grip" not in kept:actor["integrated"]["weapons"]=actor["integrated"]["weapons"].slice(0,1)
		if actor["integrated"]["focus_binding"] not in kept or "focus_vow" not in kept:actor["integrated"]["focus_binding"]=""


func _compute_stats(actor: Dictionary, include_form: bool, legacy_weapon: bool = true) -> Dictionary:
	var result: Dictionary = jobs[actor["job_id"]]["stats"].duplicate(true)
	for identifier in actor["mastered_jobs"]:
		for stat in jobs[identifier]["stat_growth"]:
			result[stat] = int(result.get(stat, 0)) + int(jobs[identifier]["stat_growth"][stat])
	if actor.has("integrated"):
		var bonus:=IntegratedProgression.growth(actor)
		for key in bonus:result[key]+=bonus[key]
		if legacy_weapon:result["attack"]=maxi(1,int(result["attack"])+IntegratedProgression.weapon_bonus(actor))
	if include_form and not str(actor["monster_form"]).is_empty():
		var modifiers: Dictionary = jobs[actor["monster_form"]]["monster_form"]["stat_modifiers"]
		for stat in modifiers:
			result[stat] = int(result.get(stat, 0)) + int(modifiers[stat])
	for stat in result:
		result[stat] = int(result[stat])
	return result


func equipment_stats(actor: Dictionary, document: Dictionary) -> Dictionary:
	# _stateを読まない。reserveも同じ明示documentから導出する。
	var view = preload("res://scripts/game/equipment_state_view.gd").project(document)
	if not view.ok:return {}
	var bonus = preload("res://scripts/game/equipment_rules.gd").new().equipment_bonuses(view.view,actor.get("id",""))
	if not bonus.ok:return {}
	var stats := _compute_stats(actor,true,false)
	for key in bonus.bonuses:
		var addition: int = bonus.bonuses[key]
		if addition > 0 and stats[key] > 9223372036854775807 - addition:return {}
		if addition < 0 and stats[key] < -9223372036854775807 - addition:return {}
		stats[key] += addition
	stats.attack = maxi(1,stats.attack)
	return stats


func effective_stats(actor_id: String) -> Dictionary:
	var actor := _member(actor_id)
	return {} if actor.is_empty() else _compute_stats(actor, true)


func mastery_trait(job_id: String) -> Dictionary:
	if not jobs.has(job_id):
		return {}
	var growth: Dictionary = jobs[job_id]["stat_growth"]
	var names := {"hp":"HP","mp":"MP","attack":"攻撃","defense":"防御","magic":"魔力","resistance":"魔防","speed":"速さ"}
	var effects: Array[String] = []
	for stat in growth:
		effects.append(str(names[stat])+" +"+str(int(growth[stat])))
	return {"id":"mastery_"+job_id,"name":str(jobs[job_id]["name"])+"の鍛錬","description":" / ".join(effects),"stat_growth":growth.duplicate(true)}


func mastery_traits(actor_id: String) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for identifier in _member(actor_id).get("mastered_jobs",[]):
		result.append(mastery_trait(identifier))
	return result


func mastery_progress(actor_id: String, job_id: String) -> Dictionary:
	var actor := _member(actor_id)
	if actor.is_empty() or not jobs.has(job_id):return {}
	var condition: Dictionary=jobs[job_id]["mastery_action"]
	return {"count":JobMastery.count(actor,job_id),"required":int(condition["required"]),"description":condition["description"],"active":JobMastery.active(actor),"met":JobMastery.ready(actor,jobs[job_id]),"legacy":job_id in actor.get("integrated",{}).get("mastery",{}).get("legacy_masters",[])}


func mastery_bonus(actor_id: String) -> Dictionary:
	var result := {"hp":0,"mp":0,"attack":0,"defense":0,"magic":0,"resistance":0,"speed":0}
	for trait_entry in mastery_traits(actor_id):
		for stat in trait_entry["stat_growth"]:
			result[stat] += int(trait_entry["stat_growth"][stat])
	return result


func mastery_bonus_text(actor_id: String) -> String:
	var names := {"hp":"HP","mp":"MP","attack":"攻撃","defense":"防御","magic":"魔力","resistance":"魔防","speed":"速さ"}
	var bonus := mastery_bonus(actor_id)
	var parts: Array[String] = []
	for stat in names:
		if bonus[stat] != 0:
			parts.append("%s %+d" % [names[stat], bonus[stat]])
	return "常時特性の合計: " + ("未取得" if parts.is_empty() else " / ".join(parts))


func base_effective_stats(actor_id: String) -> Dictionary:
	var actor := _member(actor_id)
	return {} if actor.is_empty() else _compute_stats(actor, false)


func preview_job(actor_id: String, job_id: String) -> Dictionary:
	var actor := _member(actor_id)
	if actor.is_empty() or not jobs.has(job_id):
		return {}
	var candidate := actor.duplicate(true)
	candidate["job_id"] = job_id
	if jobs[job_id]["type"] == "monster" and job_id in candidate["mastered_jobs"]:
		candidate["monster_form"] = job_id
	return {"allowed": _battle == null and not (actor["irreversible"] and jobs[job_id]["type"] == "human"),
		"stats": _compute_stats(candidate, true), "monster_form": candidate["monster_form"],
		"jp": int(actor["jp"].get(job_id,0)), "mastery_cost": IntegratedProgression.cost(jobs[job_id],IntegratedProgression.modern(_state))}


func describe_ability(ability_id: String,actor_id: String="") -> String:
	if not abilities.has(ability_id):
		return ""
	var ability: Dictionary = abilities[ability_id]
	var targets := {"enemy":"敵1体", "ally":"味方1人", "self":"自分", "fallen_ally":"戦闘不能の味方1人","enemies":"敵全体","allies":"味方全体"}
	var detail: String=ability.get("description","")
	match ability["kind"]:
		"physical": detail = "物理攻撃%d%% × %d回" % [ability["power"], ability["hits"]]
		"magic": detail = "%s魔法・威力%d" % [{"none":"無属性", "fire":"炎属性", "ice":"氷属性","electric":"電属性"}[ability["element"]], ability["power"]]
		"heal": detail = "HP回復・回復量は%d＋魔力×2" % ability["power"]
		"revive": detail = "最大HPの%d%%で蘇生" % ability["power"]
		"guard": detail = "このターンの被ダメージを%d%%に抑える" % ability["power"]
		"steal": detail = "相手1体につき1回、回復薬を盗む"
	if int(ability["priority"]) > 0:
		detail += "・優先行動"
	if not monster_skill_origin(ability_id).is_empty():
		detail += "・実使用で侵蝕+0.1" if IntegratedProgression.modern(_state) else "・実使用で侵蝕+%d" % MONSTER_SKILL_EROSION
	var actual:=int(ability["cost"])
	var actor:=_member(actor_id)
	if not actor.is_empty() and actor.has("integrated"):
		actual=IntegratedProgression.ability_cost(ability,catalog.integration["affinities"].get(actor["job_id"],[]),int(IntegratedProgression.form_rule(actor).get("mp_add",0)))
		if actual!=int(ability["cost"]):detail+="\n基礎%dMPから現在職の得意・形態の補正を適用。" % ability["cost"]
	return "%s / %dMP / %s\n%s" % [ability["name"], actual, targets[ability["target"]], detail]


func monster_skill_origin(ability_id: String) -> String:
	for job in jobs.values():
		if job["type"] == "human" and ability_id in job["abilities"]:
			return ""
	for job in jobs.values():
		if job["type"] == "monster" and (ability_id in job["abilities"] or ability_id in job["monster_form"]["abilities"]):
			return job["id"]
	return ""


static func erosion_stage(value: int) -> String:
	if value >= 90:
		return "不可逆"
	if value >= 60:
		return "変異"
	if value >= 30:
		return "兆候"
	return "平常"


func current_erosion(actor_id: String) -> float:
	var actor := _member(actor_id)
	if actor.is_empty():
		return 0
	if actor.has("integrated"):
		var units:=IntegratedProgression.erosion_tenths(actor)
		if _battle!=null:
			for ability_id in _battle.successful_abilities(actor_id):
				if not monster_skill_origin(ability_id).is_empty():units+=1
		return minf(100.0,units/10.0)
	var value := int(actor["erosion"])
	if _battle != null:
		for ability_id in _battle.successful_abilities(actor_id):
			if not monster_skill_origin(ability_id).is_empty():
				value += MONSTER_SKILL_EROSION
	return mini(100, value)


func erosion_preview(include_queued: bool = false) -> Array[Dictionary]:
	if IntegratedProgression.modern(_state):return _integrated_erosion_preview(include_queued)
	var results: Array[Dictionary] = []
	for actor in _state.get("party", []):
		var before := int(actor["erosion"])
		var battle_cost := MONSTER_BATTLE_EROSION if jobs[actor["job_id"]]["type"] == "monster" else 0
		var after := mini(100, before + battle_cost)
		var skill_count := 0
		var forced_job := ""
		var uses: Array[String] = []
		if _battle != null:
			uses = _battle.successful_abilities(actor["id"])
			if include_queued and _battle.queued.has(actor["id"]):
				var action: BattleAction = _battle.queued[actor["id"]]
				if action.kind == BattleAction.Kind.ABILITY:
					uses.append(action.ability_id)
		for ability_id in uses:
			var origin := monster_skill_origin(ability_id)
			if origin.is_empty():
				continue
			var previous := after
			after = mini(100, after + MONSTER_SKILL_EROSION)
			skill_count += 1
			if previous < 90 and after >= 90 and jobs[actor["job_id"]]["type"] == "human":
				forced_job = origin
		results.append({"actor":actor["id"], "name":actor["name"], "before":before, "after":after,
			"battle_cost":battle_cost, "skill_uses":skill_count, "forced_job":forced_job,
			"crosses_irreversible": before < 90 and after >= 90})
	return results


func _refresh_caps(actor: Dictionary) -> void:
	var current := _compute_stats(actor, true)
	for pair in [["hp", "max_hp"], ["mp", "max_mp"]]:
		var field: String = pair[0]
		var maximum: String = pair[1]
		var previous_max: int = int(actor[maximum])
		var next_max: int = int(current[field])
		if previous_max <= 0:
			actor[field] = next_max
		elif actor[field] == previous_max:
			actor[field] = next_max
		else:
			var previous_value := int(actor[field])
			actor[field] = floori(float(previous_value) / float(previous_max) * float(next_max))
			if field == "hp" and previous_value > 0:
				actor[field] = maxi(1, int(actor[field]))
		actor[maximum] = next_max


func _learn_form(actor: Dictionary, job_id: String) -> void:
	for identifier in jobs[job_id]["monster_form"]["abilities"]:
		if not identifier in actor["learned_abilities"] and identifier not in actor.get("integrated",{}).get("forgotten",[]):
			actor["learned_abilities"].append(identifier)


func at_purification_shrine() -> bool:
	if not first_region_active():return world_state()["location"]=="town"
	return (_state["overworld"]["node"]=="first_castle" and _state["overworld"]["room"]==8) or (_state["overworld"]["node"] in ["first_port","brine_port"] and _state["overworld"]["room"]==5) or (_state["overworld"]["node"]=="region2_village" and _state["overworld"]["room"]==4)

func release_monster_form(actor_id: String, event: String) -> bool:
	if _battle != null:
		return false
	if first_region_active() and not at_purification_shrine():return false
	var actor := _member(actor_id)
	if actor.is_empty() or (str(actor["monster_form"]).is_empty() and int(actor["erosion"]) == 0):
		return false
	var release: Dictionary = {"event":"purification_shrine","max_erosion":89,"erosion_reduction":30,"forget_monster_abilities":true} if str(actor["monster_form"]).is_empty() else jobs[actor["monster_form"]]["monster_form"]["release"]
	if event != release["event"] or actor["irreversible"] or int(actor["erosion"]) > int(release["max_erosion"]):
		return false
	_grant_job_unlocks(actor)
	var monster_skills: Array[String] = _form_abilities()
	var human_skills: Array[String] = []
	for job in jobs.values():
		for identifier in job["abilities"]:
			if job["type"] == "human":
				human_skills.append(identifier)
			else:
				monster_skills.append(identifier)
	var removed: Array=[]
	if release["forget_monster_abilities"]:
		var kept: Array[String] = []
		for identifier in actor["learned_abilities"]:
			if not identifier in monster_skills or identifier in human_skills:
				kept.append(identifier)
			else:removed.append(identifier)
		actor["learned_abilities"] = kept
	actor["monster_form"] = ""
	if actor.has("integrated"):
		IntegratedProgression.forget(actor,removed)
		IntegratedProgression.set_erosion(actor,IntegratedProgression.erosion_tenths(actor)-int(release["erosion_reduction"])*10)
	else:actor["erosion"] = maxi(0,int(actor["erosion"])-int(release["erosion_reduction"]))
	if jobs[actor["job_id"]]["type"] == "monster":
		actor["job_id"] = actor["last_human_job"]
	_refresh_caps(actor)
	_reconcile_slots(actor)
	return true


func start_battle(enemy_ids: Array, random_seed: int) -> BattleState:
	if _state.is_empty() or party_defeated() or _battle != null or enemy_ids.is_empty() or enemy_ids.size() > 4:
		return null
	for identifier in enemy_ids:
		if not enemy_definitions.has(identifier):
			return null
	var party: Array[Combatant] = []
	for saved in _state["party"]:
		var actor := Combatant.new(saved["id"], saved["name"], Combatant.Team.PARTY, _compute_stats(saved, true))
		actor.job_id = saved["job_id"]
		actor.hp = saved["hp"]
		actor.mp = saved["mp"]
		actor.learned = _available(saved)
		actor.equipped.assign(saved["equipped_abilities"])
		if saved.has("integrated"):
			actor.affinities.assign(catalog.integration["affinities"].get(saved["job_id"],[]))
			actor.focus_binding=saved["integrated"]["focus_binding"]
			for id in saved["integrated"]["weapons"]:actor.weapons.append(IntegratedProgression.weapon(id).duplicate(true))
			actor.primary_weapon_attack=IntegratedProgression.weapon_bonus(saved)
			var form:=IntegratedProgression.form_rule(saved)
			actor.form_mp_add=int(form.get("mp_add",0));actor.physical_taken=float(form.get("physical_rate",1));actor.magic_taken=float(form.get("magic_rate",1))
		party.append(actor)
	var foes: Array[Combatant] = []
	for i in range(enemy_ids.size()):
		var definition: Dictionary = enemy_definitions[enemy_ids[i]]
		var actor := Combatant.new("enemy_%02d" % (i + 1), definition["name"], Combatant.Team.ENEMY, definition["stats"])
		actor.learned.assign(definition["abilities"])
		actor.equipped.assign(definition["abilities"])
		actor.weaknesses.assign(definition["weaknesses"])
		actor.tactics = definition.get("tactics",actor.tactics).duplicate(true)
		foes.append(actor)
	_battle = BattleState.new(party, foes, catalog, random_seed)
	_world_battle_id = ""
	_battle.potions = int(_state["inventory"]["potion"])
	if IntegratedProgression.modern(_state):_battle.effects.knowledge=_state["integrated"]["knowledge"].duplicate(true)
	for member in _state["party"]:
		if JobMastery.active(member):_battle.mastery_conditions[member["id"]]=jobs[member["job_id"]]["mastery_action"].duplicate(true)
	_battle_enemy_ids.assign(enemy_ids)
	_claimed = false
	_field_battle = false
	_story_wave_step = -1
	_expedition_battle_stage = -1
	return _battle


func party_defeated() -> bool:
	if _state.is_empty():
		return false
	for actor in _state["party"]:
		if actor["hp"] > 0:
			return false
	return true


func story_wave_index() -> int:
	if not _state.get("expedition",{}).is_empty():
		return int(_state["expedition"]["wave"])
	var progress: Dictionary = _state.get("story_battle",{})
	return int(progress.get("cleared",0)) if progress.get("step") == world_state().get("quest_step") else 0


func story_wave_count() -> int:
	return StoryCampaign.battle_waves(current_story_step()).size()


func story_battle_cleared() -> bool:
	return story_wave_count() > 0 and story_wave_index() == story_wave_count()


func start_story_battle() -> BattleState:
	if world_exploration_active():
		return null
	var entry := current_story_step()
	var world := world_state()
	if _battle != null or is_returning_to_town() or entry.get("kind") != "battle" or world["location"] != entry["location"] or world["player_cell"] != entry["cell"]:
		return null
	var waves := StoryCampaign.battle_waves(entry)
	var next := story_wave_index()
	if next >= waves.size():
		return null
	var encounter := start_battle(waves[next],int(entry.get("seed",20260919+int(world["quest_step"])))+next*1000)
	if encounter != null:
		if IntegratedProgression.modern(_state):encounter.effects.configure(integrated_rule(),_state["integrated"]["knowledge"])
		_story_wave_step = int(world["quest_step"])
		_story_wave_number = next
		if not _state.get("expedition",{}).is_empty():
			_expedition_battle_stage = int(_state["expedition"]["stage"])
	return encounter


func field_battle_enemies() -> Array:
	var world := world_state()
	if world.is_empty() or story_complete():
		return []
	if not _state.get("expedition",{}).is_empty():
		return [["slime"],["bat"]][int(_state.get("field_battles",0))%2]
	var encounters: Array = []
	if world["location"] == "waterway" and world["quest_step"] >= 3:
		encounters = [["slime"], ["bat"]]
	elif world["location"] == "cave" and world["quest_step"] >= 7:
		encounters = [["shell_guard"], ["ember_wisp"]]
	elif world["location"] in ["school", "records"]:
		encounters = [["shell_guard"], ["ember_wisp"]]
	if encounters.is_empty():
		return []
	return encounters[int(_state.get("field_battles", 0)) % encounters.size()].duplicate()


func start_field_battle() -> BattleState:
	var enemies := field_battle_enemies()
	if enemies.is_empty():
		return null
	var encounter := start_battle(enemies, 20260919 + int(_state.get("field_battles", 0)))
	if encounter != null:
		_field_battle = true
	return encounter


func current_enemy_ids() -> Array[String]:
	return _battle_enemy_ids.duplicate()


func is_field_battle() -> bool:
	return _battle != null and (_field_battle or not _world_battle_id.is_empty())


func is_world_battle() -> bool:
	return _battle != null and not _world_battle_id.is_empty()


func finish_battle() -> bool:
	if _battle == null or _claimed or not _battle.phase in [BattleState.Phase.VICTORY, BattleState.Phase.DEFEAT]:
		return false
	_claimed = true
	if _field_battle:
		_state["field_battles"] = int(_state.get("field_battles", 0)) + 1
	var won: bool = _battle.phase == BattleState.Phase.VICTORY
	if won and first_region_active() and _world_battle_id == "first_boss":
		_state["inventory"]["gate_pass"] = 1
	if won and not _world_battle_id.is_empty() and _world_battle_id not in _state["overworld"]["cleared"]:
		_state["overworld"]["cleared"].append(_world_battle_id)
	if won and _expedition_battle_stage >= 0:
		_state["expedition"]["wave"] = _story_wave_number+1
	elif won and _story_wave_step >= 0:
		_state["story_battle"] = {"step":_story_wave_step,"cleared":_story_wave_number+1}
	var reward := 0
	if won:
		for identifier in _battle_enemy_ids:
			reward += int(enemy_definitions[identifier]["jp"])
	_state["inventory"]["potion"] = _battle.potions
	var erosion_results := erosion_preview()
	var battle_result := {"enemies":_battle_enemy_ids.duplicate(),"victory":won,"rounds":_battle.round_number,"jp":reward,"erosion":erosion_results.duplicate(true),"remaining":_battle.snapshot()["actors"]}
	var member_index := 0
	for actor in _state["party"]:
		var combatant := _battle.actor_by_id(actor["id"])
		actor["hp"] = combatant.hp
		actor["mp"] = combatant.mp
		var job: Dictionary = jobs[actor["job_id"]]
		var erosion: Dictionary = erosion_results[member_index]
		if JobMastery.active(actor):
			var counts: Dictionary=actor["integrated"]["mastery"]["counts"]
			counts[actor["job_id"]]=mini(int(job["mastery_action"]["required"]),JobMastery.count(actor,actor["job_id"])+int(_battle.mastery_counts.get(actor["id"],0)))
		member_index += 1
		if actor.has("integrated"):IntegratedProgression.set_erosion(actor,int(erosion["after_tenths"]))
		else:actor["erosion"] = erosion["after"]
		if actor["erosion"] >= 90:
			actor["irreversible"] = true
		if won:
			var modern: bool=actor.has("integrated")
			if modern:
				var award:=IntegratedProgression.reward(_integration_reward_kind())
				var change:=IntegratedProgression.apply_reward(actor,job,award,job["type"]=="human" and int(actor["erosion"])>=60)
				play_metrics.record_event("growth_awarded",{"actor":actor["id"],"change":change})
			else:
				var earned:=floori(reward/2.0) if job["type"]=="human" and int(actor["erosion"])>=60 else reward
				actor["jp"][actor["job_id"]]=int(actor["jp"].get(actor["job_id"],0))+earned
			var jp:=int(actor["jp"][actor["job_id"]])
			var cost:=IntegratedProgression.cost(job,modern)
			var old_skills:=IntegratedProgression.skill_list(job,false)
			if not modern and jp>=ceili(cost/2.0) and old_skills[0] not in actor["learned_abilities"]:actor["learned_abilities"].append(old_skills[0])
			if jp>=cost:
				for identifier in IntegratedProgression.skill_list(job,modern):
					if identifier not in actor["learned_abilities"] and identifier not in actor.get("integrated",{}).get("forgotten",[]):actor["learned_abilities"].append(identifier)
				if actor["job_id"] not in actor["mastered_jobs"] and JobMastery.ready(actor,job):
					actor["mastered_jobs"].append(actor["job_id"])
					if job["type"]=="monster":
						actor["monster_form"]=actor["job_id"]
						_learn_form(actor,actor["job_id"])

		# JPは戦闘時の職へ与え、その後に90到達時の職業移行を反映する。
		if not str(erosion["forced_job"]).is_empty():
			actor["job_id"] = erosion["forced_job"]
			if actor["job_id"] in actor["mastered_jobs"]:
				actor["monster_form"] = actor["job_id"]
				_learn_form(actor, actor["job_id"])
		_refresh_caps(actor)
		_reconcile_slots(actor)
		_grant_job_unlocks(actor)
	if IntegratedProgression.modern(_state):
		_state["integrated"]["knowledge"]=_battle.effects.knowledge.duplicate(true)
		if won:_record_integrated_outcome()
	play_metrics.record_event("battle_finished",battle_result)
	_battle = null
	_world_battle_id = ""
	_field_battle = false
	_story_wave_step = -1
	_expedition_battle_stage = -1
	return true


func rest() -> bool:
	if _battle != null or _state.is_empty():
		return false
	for actor in _state["party"]:
		actor["hp"] = actor["max_hp"]
		actor["mp"] = actor["max_mp"]
	return true


func world_state() -> Dictionary:
	return _state.get("world", {}).duplicate(true)


func world_exploration_active() -> bool:
	return bool(_state.get("overworld",{}).get("active",false))


func overworld_state() -> Dictionary:
	return _state.get("overworld",{}).duplicate(true)


func open_world_exploration() -> bool:
	if _state.is_empty() or _battle != null or party_defeated():
		return false
	if world_exploration_active():
		return true
	var origin: String = world_state()["location"]
	if origin not in ChapterOne.TOWNS or not _state.get("expedition",{}).is_empty():
		return false
	var candidate := WorldExpedition.initial(origin,_state["progress_flags"])
	if _state.has("overworld"):
		for key in ["seen","cleared","choices","visited","flags"]:
			candidate[key] = _state["overworld"][key].duplicate(true)
		if _state["progress_flags"].get("chapter1_cleared",false):
			candidate["flags"]["world_causeway_open"] = true
	if not WorldExpedition.valid(candidate):
		return false
	_state["overworld"] = candidate
	play_metrics.record_event("world_exploration_started",{"origin":origin})
	return true


func close_world_exploration() -> bool:
	if not world_exploration_active() or _battle != null or not WorldExpedition.at_origin(_state["overworld"]):
		return false
	_state["overworld"]["active"] = false
	return true


func move_overworld(cell: Vector2i) -> bool:
	if not world_exploration_active() or _battle != null or party_defeated():
		return false
	var moved := WorldExpedition.move(_state["overworld"],cell)
	if moved:
		play_metrics.mark("moved_cells")
	return moved


func change_world_transport(mode: String) -> bool:
	return not first_region_active() and world_exploration_active() and _battle == null and WorldExpedition.change_transport(_state["overworld"],mode)


func interact_overworld() -> Dictionary:
	if not world_exploration_active() or _battle != null or party_defeated():
		return {}
	var result := WorldExpedition.interact(_state["overworld"])
	if result.get("kind") == "rest":
		rest()
		result["kind"] = "dialogue"
		result["text"].append("全員のHPとMPが回復しました。")
	return result


func choose_world_option(option: int) -> Dictionary:
	if not world_exploration_active() or _battle != null:
		return {}
	var result := WorldExpedition.choose(_state["overworld"],option)
	if not result.is_empty():
		_state["inventory"]["potion"] += result["potions"]
		play_metrics.record_event("world_site_completed",{"site":_state["overworld"]["node"],"option":option,"grant":result["grant"]})
	return result


func start_world_battle() -> BattleState:
	if not world_exploration_active() or _battle != null:
		return null
	var state: Dictionary = _state["overworld"]
	var event := WorldExpedition.event_at(state)
	if event.get("kind") != "battle" or WorldExpedition.done(state,event["id"]) or not WorldExpedition.ready(state,event):
		return null
	var encounter := start_battle(event["enemies"],20260921+int(WorldExpedition.node(state["node"])["progression_index"])*10+state["room"])
	if encounter != null:
		_world_battle_id = event["id"]
		if IntegratedProgression.modern(_state):encounter.effects.configure(integrated_rule(),integration_knowledge())
	return encounter


func is_returning_to_town() -> bool:
	return not _state.get("return_point", {}).is_empty()


func return_to_town() -> bool:
	if _state.is_empty() or _battle != null or is_returning_to_town() or _state["world"]["location"] in ChapterOne.TOWNS or story_complete():
		return false
	var previous := world_state()
	if not set_world("town", [5,4], previous["quest_step"]):
		return false
	_state["return_point"] = previous
	return true


func resume_exploration() -> bool:
	if _battle != null or not is_returning_to_town():
		return false
	var previous: Dictionary = _state["return_point"]
	if not set_world(previous["location"], previous["player_cell"], previous["quest_step"],previous.get("section","")):
		return false
	_state["return_point"] = {}
	return true


func set_world(location: String, cell: Array, quest_step: int, section: String = "") -> bool:
	if world_exploration_active():
		return false
	if _state.is_empty() or _battle != null or not ChapterOne.TITLES.has(location) or cell.size() != 2:
		return false
	var position := Vector2i(int(cell[0]),int(cell[1]))
	var walkable: bool = ExplorationSites.is_walkable(location,position,_state["progress_flags"]) if section.is_empty() else CampaignContent.section(section).get("location") == location and CampaignContent.is_walkable(section,position,_state["progress_flags"])
	if not walkable or quest_step < 0 or quest_step > StoryCampaign.total_steps():
		return false
	_state["world"] = {"location": location, "player_cell": [int(cell[0]), int(cell[1])], "quest_step": quest_step}
	if not section.is_empty():
		_state["world"]["section"] = section
	return true


func current_story_step() -> Dictionary:
	if not _state.get("expedition",{}).is_empty():
		return CampaignContent.step(_state["expedition"],_state["progress_flags"])
	var base := StoryCampaign.step(int(world_state().get("quest_step",0)), _state.get("story_task", {}))
	if not _state.is_empty():
		var pending := CampaignContent.pending(_state)
		if not pending.is_empty():
			base["kind"] = "expedition"
			base["expedition_id"] = pending["id"]
			base["objective"] = pending["title"]+"へ進む"
	return base


func begin_expedition(identifier: String) -> bool:
	var pending := CampaignContent.pending(_state,identifier)
	var entry := current_story_step()
	if _battle != null or pending.get("id") != identifier or world_state().get("player_cell") != entry.get("cell"):
		return false
	var candidate := _state.duplicate(true)
	candidate["expedition"] = {"id":identifier,"stage":0,"wave":0,"origin":world_state(),"solved":[]}
	var room: Dictionary = pending["sections"][0]
	candidate["world"] = {"location":room["location"],"player_cell":room["spawn"].duplicate(),"section":room["id"],"quest_step":pending["trigger_step"]}
	if not _valid_state(candidate):
		return false
	_state = candidate
	play_metrics.mark("circuits_started")
	return true


func long_missions() -> Array[Dictionary]:
	if _state.is_empty():return []
	# 既存の点検を終えるまでは、その地点の長編依頼へ進ませない。
	var pending:=CampaignContent.pending(_state)
	if pending.is_empty() or LongCampaign.mission(pending.get("id","")).is_empty():return []
	return LongCampaign.available(_state)


func answer_challenge(option: int) -> bool:
	var entry := current_story_step()
	if _battle != null or is_returning_to_town() or entry.get("kind") != "challenge" or world_state()["player_cell"] != entry["cell"] or option not in range(entry["options"].size()):
		return false
	if entry.has("required_activity") and not _state["progress_flags"].get(LongCampaign.activity_flag(entry["required_activity"],"done"),false):
		return false
	play_metrics.mark("challenge_attempts")
	var accepted: bool=entry.get("choice",false) or option==entry["answer"]
	play_metrics.record_event("challenge_answer",{"id":entry["id"],"option":option,"correct":accepted})
	if not accepted:
		play_metrics.mark("challenge_mistakes")
		return false
	return _advance_expedition(true,option)


func _advance_expedition(challenge_answered: bool = false, option: int = -1) -> bool:
	var entry := current_story_step()
	if _battle != null or is_returning_to_town() or world_state()["player_cell"] != entry["cell"]:
		return false
	if entry["kind"] == "challenge" and not challenge_answered:
		return false
	if entry["kind"] == "battle" and not story_battle_cleared():
		return false
	var candidate := _state.duplicate(true)
	var expedition: Dictionary = candidate["expedition"]
	var is_long:=not LongCampaign.mission(expedition["id"]).is_empty()
	if entry["kind"] == "circuit_complete":
		var completed_flag: String=LongCampaign.cleared_flag(expedition["id"]) if is_long else "circuit_"+expedition["id"]+"_cleared"
		candidate["progress_flags"][completed_flag] = true
		candidate["world"] = expedition["origin"].duplicate(true)
		candidate["expedition"] = {}
	else:
		if entry["kind"] == "challenge":
			expedition["solved"].append(entry["id"])
			apply_challenge_reward(candidate,entry)
			if is_long and entry.get("choice",false):
				if option not in range(entry["options"].size()):return false
				candidate["progress_flags"][LongCampaign.choice_flag(entry["id"],option)]=true
				var effects: Array=entry.get("choice_effects",[])
				if option<effects.size():
					for flag in effects[option].get("flags",[]):candidate["progress_flags"][flag]=true
					candidate["inventory"]["potion"]+=int(effects[option].get("potion_bonus",0))
		expedition["stage"] += 1
		expedition["wave"] = 0
		if entry["kind"] == "section_travel":
			candidate["world"]["section"] = entry["destination"]
			candidate["world"]["player_cell"] = entry["spawn"].duplicate()
	if not _valid_state(candidate):
		return false
	_state = candidate
	if entry["kind"] == "circuit_complete":
		play_metrics.mark("long_missions_completed" if is_long else "circuits_completed")
	return true


static func apply_challenge_reward(state: Dictionary, entry: Dictionary) -> void:
	state["inventory"]["potion"] += int(entry.get("reward_potions",0))
	for actor in state["party"]:
		if actor["hp"]<=0:continue
		for pair in [["hp","max_hp","reward_hp_percent"],["mp","max_mp","reward_mp_percent"]]:
			var recovered:=ceili(float(actor[pair[1]])*float(entry.get(pair[2],0))/100.0)
			actor[pair[0]]=mini(actor[pair[1]],actor[pair[0]]+recovered)


func world_walkable_cells() -> Array:
	if not str(world_state().get("section","")).is_empty():
		return CampaignContent.walkable_cells(world_state()["section"],_state["progress_flags"])
	var location: String = world_state().get("location","")
	var result := ChapterOne.walkable_cells(location)
	for site in exploration_sites():
		if site["kind"] == "device" and site["complete"]:
			for cell in site["opens"]:
				if not cell in result:
					result.append(cell)
	return result


func exploration_sites() -> Array[Dictionary]:
	if not str(world_state().get("section","")).is_empty():
		var result:=long_activity_markers()
		var rule:=integrated_rule()
		if not rule.is_empty() and not is_returning_to_town():
			for i in range(2):
				result.append({"id":"mechanism_"+str(i),"kind":"record","name":"機構の観察","cell":[4,8] if i==0 else [18,8],"complete":i in integration_knowledge().get(rule["id"],{}).get("facts",[])})
		return result
	return ExplorationSites.in_location(world_state().get("location",""),_state.get("progress_flags",{}))


func long_activity() -> Dictionary:
	if _state.is_empty() or is_returning_to_town():return {}
	var active: Dictionary = _state.get("expedition",{})
	var mission := LongCampaign.mission(active.get("id",""))
	for activity in mission.get("activities",[]):
		if activity["section"] == world_state().get("section","") and int(active.get("stage",-1)) >= activity["unlock_stage"]:
			return activity.duplicate(true)
	return {}


func long_activity_markers() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var activity := long_activity()
	if activity.is_empty():return result
	for i in range(activity["observations"].size()):
		result.append({"id":activity["id"]+"_seen_"+str(i),"kind":"record","name":"観察記録"+str(i+1),"cell":activity["observations"][i]["cell"],"complete":_state["progress_flags"].get(LongCampaign.activity_flag(activity["id"],"seen_"+str(i)),false),"observation":i})
	result.append({"id":activity["id"],"kind":"device","name":activity["name"],"cell":activity["cell"],"complete":_state["progress_flags"].get(LongCampaign.activity_flag(activity["id"],"done"),false),"observation":-1})
	return result


func long_activity_at_player() -> Dictionary:
	for marker in long_activity_markers():
		if marker["cell"] == world_state()["player_cell"]:return marker
	return {}


func read_long_observation() -> Array:
	var marker := long_activity_at_player()
	if _battle != null or marker.is_empty() or int(marker["observation"]) < 0:return []
	var activity := long_activity()
	var index: int = marker["observation"]
	_state["progress_flags"][LongCampaign.activity_flag(activity["id"],"seen_"+str(index))] = true
	return [activity["observations"][index]["text"]]


func complete_long_activity(answer: int, support_actor: String = "") -> bool:
	var marker := long_activity_at_player()
	var activity := long_activity()
	if _battle != null or marker.is_empty() or activity.is_empty() or marker["kind"] != "device" or marker["complete"] or answer != int(activity["answer"]):return false
	for i in range(2):
		if not _state["progress_flags"].get(LongCampaign.activity_flag(activity["id"],"seen_"+str(i)),false):return false
	var candidate := _state.duplicate(true)
	if not support_actor.is_empty():
		var actor := _member(support_actor)
		var skill: String = activity["support_ability"]
		if actor.is_empty() or actor["hp"] <= 0 or skill not in actor["equipped_abilities"] or actor["mp"] < abilities[skill]["cost"]:return false
		for member in candidate["party"]:
			if member["id"] == support_actor:member["mp"] -= int(abilities[skill]["cost"])
		candidate["progress_flags"][activity["support_flag"]] = true
	candidate["progress_flags"][LongCampaign.activity_flag(activity["id"],"done")] = true
	if not _valid_state(candidate):return false
	_state = candidate
	play_metrics.record_event("long_field_completed",{"id":activity["id"],"answer":answer,"support":support_actor})
	return true


func exploration_at_player() -> Dictionary:
	for site in exploration_sites():
		if site["cell"] == world_state()["player_cell"]:
			return site
	return {}


func exploration_options() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	if not long_activity_at_player().is_empty():return result
	var site := exploration_at_player()
	if _battle != null or site.is_empty() or site["complete"]:
		return result
	if site["kind"] == "cache":
		result.append({"actor":"","ability":"","label":"回復薬%d個を受け取る" % site["potions"],"allowed":bool(_state["progress_flags"].get("exploration_"+site["requires"],false))})
		return result
	for actor in _state["party"]:
		for skill in site["abilities"]:
			var cost := int(abilities[skill]["cost"])
			result.append({"actor":actor["id"],"ability":skill,"label":"%s・%s（%dMP）" % [actor["name"],abilities[skill]["name"],cost],
				"allowed":actor["hp"] > 0 and skill in actor["equipped_abilities"] and skill in _available(actor) and actor["mp"] >= cost})
	return result


func use_exploration_site(actor_id: String = "", ability_id: String = "") -> bool:
	var site := exploration_at_player()
	for option in exploration_options():
		if not option["allowed"] or option["actor"] != actor_id or option["ability"] != ability_id:
			continue
		var candidate := _state.duplicate(true)
		if site["kind"] == "cache":
			candidate["inventory"]["potion"] += int(site["potions"])
		else:
			for actor in candidate["party"]:
				if actor["id"] == actor_id:
					actor["mp"] -= int(abilities[ability_id]["cost"])
		candidate["progress_flags"]["exploration_"+site["id"]] = true
		if not _valid_state(candidate):
			return false
		_state = candidate
		return true
	return false


func journal_entries() -> Array[Dictionary]:
	var entries := StoryCampaign.journal(_state.get("progress_flags", {}))
	entries.append_array(LongCampaign.journal(_state))
	for entry in entries:
		if entry["id"] == "R05":
			var chosen: Array[String] = []
			var unused: Array[String] = []
			for identifier in StoryCampaign.data()["keeper_learned"]:
				if identifier in StoryCampaign.data()["keeper_loadout"]:
					chosen.append(describe_ability(identifier))
				else:
					unused.append(abilities[identifier]["name"])
			entry["loadout"] = "当時の装着 %d枠\n%s\n習得済み・未装着: %s" % [Loadout.capacity(false,true),"\n".join(chosen),"、".join(unused)]
	return entries

func journal_capacity() -> int:
	var count: int=StoryCampaign.data().get("clues",[]).size()
	if _state.get("progress_flags",{}).get("long_campaign_started",false):count+=LongCampaign.data().get("clues",[]).size()
	return count


func story_complete() -> bool:
	return _state.get("progress_flags", {}).get("story_v1_cleared", false)


func story_audit() -> Array[String]:
	return StoryCampaign.audit()


func chapter_one_pause() -> bool:
	var flags: Dictionary = _state.get("progress_flags", {})
	return flags.get("chapter1_cleared", false) and not flags.get("chapter1_continued", false)


func continue_story() -> bool:
	if _battle != null or not chapter_one_pause() or int(world_state().get("quest_step",0)) != ChapterOne.STEPS.size():
		return false
	_state["progress_flags"]["chapter1_continued"] = true
	return true


func story_lines(entry: Dictionary = {}) -> Array:
	if entry.is_empty():
		entry = current_story_step()
	var definition := StoryCampaign.event(entry.get("event", ""))
	if not definition.is_empty() and StoryCampaign.apply_event(_state["progress_flags"],entry["event"]).is_empty():
		return []
	var lines: Array = definition.get("text", []).duplicate()
	if lines.is_empty():
		lines = entry.get("text", []).duplicate()
	if definition.has("reaction"):
		var changed := false
		for actor in _state["party"]:
			changed = changed or int(actor["erosion"]) >= 30 or not str(actor["monster_form"]).is_empty()
		var reactions := {"archive":["記録係は、旅人の通行札を確かめて記録を開いた。","記録係は変わり始めた身体を見て一度手を止めたが、同じ通行札を確かめて記録を開いた。"],"school":["教習係は、今使える枠と習得済みの技を順に確認した。","教習係は身体の変化より先に、使える枠と覚えた技を確認した。"],"teaching":["町の人は、旅をした仲間に教習の手伝いを頼んだ。","町の人は、身体の変化した仲間にも同じ役目を頼んだ。『覚えた手順を次の人へ教えてほしい』。"]}
		lines.push_front("【現在】" + reactions[definition["reaction"]][1 if changed else 0])
	return lines


func replayable_records() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for identifier in StoryCampaign.data()["events"]:
		var definition := StoryCampaign.event(identifier)
		if definition.get("past",false) and _state["progress_flags"].get("story_event_"+identifier,false):
			result.append({"id":identifier,"text":definition["text"].duplicate()})
	return result


func start_revisit_task(identifier: String) -> bool:
	var entry := current_story_step()
	if _battle != null or is_returning_to_town() or entry.get("kind") != "choice" or world_state()["location"] != entry["location"] or world_state()["player_cell"] != entry["cell"]:
		return false
	if identifier not in ["teaching","reply"]:
		return false
	var clue_id := "R08" if identifier == "teaching" else "R05"
	if StoryCampaign.stage(_state["progress_flags"],clue_id) == 2:
		return false
	_state["story_task"] = {"id":identifier,"step":0}
	return true


func gate_requirements(team: Array) -> Array[String]:
	var reasons: Array[String] = []
	var entry := current_story_step()
	if entry.get("kind") != "gate" or world_state()["location"] != entry.get("location") or world_state()["player_cell"] != entry.get("cell") or is_returning_to_town():
		return ["三つの操作台がある地点へ進んでください。"]
	if StoryCampaign.apply_event(_state["progress_flags"],"operation").is_empty():
		reasons.append("町の教習と番人への応答を先に確かめてください。")
	if team.size() != 3:
		reasons.append("担当する仲間を三人選んでください。")
	var seen: Array = []
	for identifier in team:
		var actor := _member(str(identifier))
		if actor.is_empty() or identifier in seen:
			reasons.append("同じ仲間を二つの操作台へ配置できません。")
			continue
		seen.append(identifier)
		if actor["hp"] <= 0:
			reasons.append(actor["name"] + "は戦闘不能です。")
		for ability_id in ["firm_guard","sound_wave"]:
			if not ability_id in _available(actor) or not ability_id in actor["equipped_abilities"]:
				reasons.append(actor["name"] + "に" + abilities[ability_id]["name"] + "の装着が必要です。")
		if actor["mp"] < gate_mp_cost():
			reasons.append(actor["name"] + "のMPが足りません。")
	return reasons


func gate_mp_cost() -> int:
	return int(abilities["firm_guard"]["cost"]) + int(abilities["sound_wave"]["cost"])


func advance_story_step(team: Array = []) -> bool:
	if world_exploration_active():
		return false
	if not _state.get("expedition",{}).is_empty():
		return _advance_expedition()
	if _battle != null or _state.is_empty() or is_returning_to_town():
		return false
	var entry := current_story_step()
	var world := world_state()
	if entry.is_empty() or world["location"] != entry["location"] or world["player_cell"] != entry["cell"]:
		return false
	if entry["kind"] == "battle" and not story_battle_cleared():
		return false
	if entry["kind"] == "choice" and (StoryCampaign.stage(_state["progress_flags"],"R05") != 2 or StoryCampaign.stage(_state["progress_flags"],"R08") != 2):
		return false
	if entry["kind"] == "gate" and (not gate_requirements(team).is_empty() or _state["progress_flags"].get("story_event_operation",false)):
		return false
	if entry["kind"] == "story_complete" and not StoryCampaign.all_resolved(_state["progress_flags"]):
		return false
	if entry["kind"]=="story_complete" and _state["progress_flags"].get("long_campaign_started",false) and not LongCampaign.all_cleared(_state["progress_flags"]):return false
	var candidate := _state.duplicate(true)
	if entry.get("id")=="v1_17" and candidate["progress_flags"].get("long_campaign_enrolled",false):candidate["progress_flags"]["long_campaign_started"]=true
	if entry["kind"] == "battle":
		candidate["story_battle"] = {}
	if entry.has("event"):
		var flags := StoryCampaign.apply_event(candidate["progress_flags"],entry["event"])
		if flags.is_empty():
			return false
		candidate["progress_flags"] = flags
		if StoryCampaign.event(entry["event"]).get("training",false):
			for actor in candidate["party"]:
				for ability_id in ["firm_guard","sound_wave"]:
					if not ability_id in actor["learned_abilities"]:
						actor["learned_abilities"].append(ability_id)
	if entry.has("flag"):
		candidate["progress_flags"][entry["flag"]] = true
	for identifier in entry.get("flags",[]):
		candidate["progress_flags"][identifier] = true
	if entry["kind"] == "gate":
		candidate["gate_team"] = team.duplicate()
		for actor in candidate["party"]:
			if actor["id"] in team:
				actor["mp"] -= gate_mp_cost()
	if entry["kind"] == "complete":
		candidate["progress_flags"]["chapter1_cleared"] = true
	if entry["kind"] == "story_complete":
		candidate["progress_flags"]["story_v1_cleared"] = true
	if entry["kind"] == "travel":
		candidate["world"]["location"] = entry["destination"]
		candidate["world"]["player_cell"] = entry["spawn"].duplicate()
	var task: Dictionary = candidate.get("story_task", {})
	if not task.is_empty():
		task["step"] += 1
		candidate["story_task"] = {} if task["step"] >= StoryCampaign.data()["branches"][task["id"]].size() else task
	else:
		candidate["world"]["quest_step"] += 1
	if not _valid_state(candidate):
		return false
	_state = candidate
	return true


func set_progress_flag(identifier: String) -> void:
	if not _state.is_empty():
		_state["progress_flags"][identifier] = true


func current_battle() -> BattleState:
	return _battle


func set_party_leader(actor_id: String) -> bool:
	if _battle != null or _member(actor_id).is_empty():
		return false
	_state["leader_id"] = actor_id
	return true


func walking_party() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var members: Array = _state.get("party",[])
	if members.is_empty():
		return result
	var leader: String = _state.get("leader_id",members[0]["id"])
	result.append(_member(leader).duplicate(true))
	for member in members:
		if member["id"] != leader:
			result.append(member.duplicate(true))
	return result


func recording_context() -> Dictionary:
	play_metrics.completed = story_complete()
	var cleared: Array[String] = []
	for circuit in CampaignContent.data()["circuits"]:
		if _state.get("progress_flags",{}).get("circuit_"+circuit["id"]+"_cleared",false):
			cleared.append(circuit["id"])
	var build := BuildIdentity.current()
	var journeys: Array[String]=[]
	for entry in LongCampaign.data().get("missions",[]):
		if _state.get("progress_flags",{}).get(LongCampaign.cleared_flag(entry["id"]),false):journeys.append(entry["id"])
	return {"engine":build["engine"],"build_id":build["id"],"build_identity_version":build["version"],"world":world_state(),"party_size":_state.get("party",[]).size(),"content_revision":_state.get("content_revision",0),"circuits_completed":cleared,"content_sha256":CampaignContent.content_hash(),"duration_target_id":DurationTarget.definition().get("id",""),"long_campaign_required":true,"long_campaign_complete":LongCampaign.all_cleared(_state.get("progress_flags",{})),"long_missions_completed":journeys}


func enable_recording(directory: String) -> bool:
	if not directory.begins_with("user://") or ".." in directory or _archive != null:
		return false
	_archive = PlaythroughArchive.new(directory)
	if not _state.is_empty():
		_archive.start(play_metrics,false)
	return true


func playthrough_id() -> String:
	return "" if _archive == null else _archive.identifier


func recording_issue() -> String:
	return "" if _archive == null else _archive.issue


func flush_recording(periodic: bool = false) -> bool:
	return true if _archive == null else _archive.flush(play_metrics,recording_context(),periodic)


func close_recording() -> bool:
	if _archive != null:
		_archive.run_open = false
	return flush_recording()


func playtest_document() -> Dictionary:
	var context := recording_context()
	if _archive != null and not _archive.identifier.is_empty():
		return _archive.document(play_metrics,context)
	var result := play_metrics.report(context)
	result["measurement_scope"] = "progress_only"
	result["history_complete"] = false
	return result


func save_playtest_report(path: String = "user://playtest-report.json") -> bool:
	if not path.begins_with("user://") or ".." in path:
		return false
	flush_recording()
	return PlaySessionMetrics.write_json(path,playtest_document())


func save_game(path: String, record_id: String = "") -> bool:
	if _battle != null or not path.begins_with("user://") or ".." in path or not _valid_state(_state):
		return false
	if not record_id.is_empty() and not PlaythroughArchive.valid_id(record_id):
		return false
	flush_recording()
	var temporary := path + ".tmp"
	var file := FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		return false
	var document := _state.duplicate(true)
	# 計測は進行状態と分離し、読むだけで進行状態の比較が変化しないようにする。
	document["_play_session"] = play_metrics.snapshot()
	var identifier := playthrough_id() if record_id.is_empty() else record_id
	if not identifier.is_empty():
		document["_trial_id"] = identifier
	var saved_types := SavedValueTypes.describe(document)
	if not saved_types["errors"].is_empty():
		file.close()
		DirAccess.remove_absolute(temporary)
		return false
	document["_saved_value_types"] = saved_types
	# 長編の操作履歴も保持したまま、表示用の空白を省いて保存量を抑える。
	file.store_string(SavedDocument.encode(document))
	file.flush()
	var written := file.get_error() == OK
	file.close()
	if not written:
		DirAccess.remove_absolute(temporary)
		return false
	return DirAccess.rename_absolute(temporary, path) == OK


## 直近の load_game で、歩けなくなった立ち位置を部屋の入口の扉の前へ置き直したか。
var position_relocated := false

## 部屋の作りが変わり、保存の立ち位置が歩けないマスになっていたら、部屋の入口の扉の前へ置き直す（FirstRegion.relocate_unwalkable）。
func _relocate_saved_position(candidate: Dictionary) -> bool:
	if not candidate.get("overworld") is Dictionary or not candidate.get("first_region") is Dictionary:return false
	var probe: Dictionary = _normalize_numbers(candidate)
	if not FirstRegion.relocate_unwalkable(probe):return false
	candidate["overworld"]["cell"] = probe["overworld"]["cell"].duplicate()
	candidate["overworld"]["entry_lock"] = probe["overworld"]["entry_lock"]
	return true


func load_game(path: String) -> bool:
	position_relocated = false
	if _battle != null or not path.begins_with("user://") or ".." in path or not FileAccess.file_exists(path):
		return false
	var document := JSON.new()
	if document.parse(FileAccess.get_file_as_string(path)) != OK or not document.data is Dictionary:
		return false
	var decoded:=SavedDocument.decode(document.data)
	if decoded.is_empty():return false
	var candidate: Dictionary = decoded.duplicate(true)
	var saved_types: Variant = candidate.get("_saved_value_types",null)
	var has_saved_types := candidate.has("_saved_value_types")
	candidate.erase("_saved_value_types")
	position_relocated = _relocate_saved_position(candidate)
	var metrics := PlaySessionMetrics.new()
	var raw_metrics: Variant = candidate.get("_play_session",{})
	if not raw_metrics is Dictionary or not metrics.restore(raw_metrics):
		return false
	candidate.erase("_play_session")
	var record_id: Variant = candidate.get("_trial_id","")
	if not record_id is String or (not record_id.is_empty() and not PlaythroughArchive.valid_id(record_id)):
		return false
	candidate.erase("_trial_id")
	if not _valid_state(_normalize_numbers(candidate)):
		return false
	var restored_state: Dictionary = _normalize_numbers(candidate)
	var restored_metrics := metrics.snapshot()
	if has_saved_types:
		var typed_document := restored_state.duplicate(true)
		typed_document["_play_session"] = restored_metrics
		if not record_id.is_empty():typed_document["_trial_id"] = record_id
		var restored := SavedValueTypes.restore(typed_document,saved_types)
		if not restored["ok"]:return false
		restored_state = restored["value"]
		restored_metrics = restored_state["_play_session"]
		restored_state.erase("_play_session")
		restored_state.erase("_trial_id")
		if not _valid_state(restored_state):return false
	if not metrics.restore(restored_metrics):return false
	for field in restored_metrics:
		if field != "version":metrics.set(field,restored_metrics[field])
	if not SavedValueTypes.same_types(metrics.snapshot(),restored_metrics):return false
	if _archive != null and _archive.identifier != record_id:
		close_recording()
	else:
		flush_recording()
	if not import_state(candidate):
		return false
	_state = restored_state
	play_metrics = metrics
	if _archive != null:
		_archive.resume(record_id,play_metrics)
		flush_recording()
	return true


func integrated_preview(actor_id: String, ability_id: String, target_id: String="") -> Dictionary:
	if _battle!=null:return _battle.preview_action(BattleAction.skill(actor_id,target_id,ability_id))
	var actor:=_member(actor_id)
	if actor.is_empty() or not abilities.has(ability_id):return {"allowed":false,"reason":"人物または技がありません。"}
	var form:=IntegratedProgression.form_rule(actor)
	var affinity: Array=catalog.integration["affinities"].get(actor["job_id"],[]) if actor.has("integrated") else []
	var value:=IntegratedProgression.ability_cost(abilities[ability_id],affinity,int(form.get("mp_add",0)))
	return {"allowed":ability_id in actor["equipped_abilities"] and ability_id in _available(actor) and actor["mp"]>=value,"cost":value,"reason":"戦闘中に対象と条件を再確認します。"}

func bind_focus(actor_id: String, ability_id: String) -> bool:
	var actor:=_member(actor_id)
	if _battle!=null or not actor.has("integrated"):return false
	if not ability_id.is_empty() and ("focus_vow" not in actor["equipped_abilities"] or ability_id not in actor["equipped_abilities"] or abilities[ability_id]["kind"] not in ["physical","magic"]):return false
	actor["integrated"]["focus_binding"]=ability_id
	return true

func equip_weapon(actor_id: String, weapon_id: String, slot: int=0) -> bool:
	var actor:=_member(actor_id)
	if _battle!=null or not actor.has("integrated") or weapon_id not in _state["integrated"]["armory"] or slot not in [0,1]:return false
	if slot==1 and "twin_grip" not in actor["equipped_abilities"]:return false
	var held: Array=actor["integrated"]["weapons"]
	if slot==held.size():held.append(weapon_id)
	else:held[slot]=weapon_id
	return true

func integration_knowledge() -> Dictionary:
	return _state.get("integrated",{}).get("knowledge",{}).duplicate(true)

func read_job_lore() -> void:
	if not IntegratedProgression.modern(_state) or _battle!=null:return
	var sources: Array=["bestiary"]
	if world_state()["location"] in ChapterOne.TOWNS:sources.append("rumor")
	for id in job_progression["advanced"]:
		for source in sources:
			var key: String=id+"/"+source
			if key not in _state["integrated"]["job_notes"]:_state["integrated"]["job_notes"].append(key)

func upgrade_rules() -> bool:
	if _battle!=null or _state.is_empty():return false
	if IntegratedProgression.modern(_state) and _state["party"].all(func(a:Dictionary)->bool:return JobMastery.active(a)):return false
	var candidate:=_state.duplicate(true) if IntegratedProgression.modern(_state) else IntegratedProgression.upgrade(_state,jobs)
	candidate["integrated"]["mastery_rules_version"]=1
	for actor in candidate["party"]:
		if not JobMastery.active(actor):actor["integrated"]["mastery"]=JobMastery.initial(actor["mastered_jobs"])
	for actor in candidate["party"]:_refresh_caps(actor)
	if not _valid_state(candidate):return false
	_state=candidate
	play_metrics.record_event("rules_upgraded",{"format_version":2})
	return true

func _integrated_erosion_preview(include_queued: bool) -> Array[Dictionary]:
	var result: Array[Dictionary]=[]
	for actor in _state["party"]:
		var before:=IntegratedProgression.erosion_tenths(actor)
		var battle_units:=2 if jobs[actor["job_id"]]["type"]=="monster" else 0
		var after:=mini(1000,before+battle_units)
		var count:=0
		var forced:=""
		var uses: Array[String]=[]
		if _battle!=null:
			uses=_battle.successful_abilities(actor["id"])
			if include_queued and _battle.queued.has(actor["id"]):
				var action: BattleAction=_battle.queued[actor["id"]]
				if action.kind==BattleAction.Kind.ABILITY and _battle._action_error(action).is_empty():uses.append(action.ability_id)
		for id in uses:
			var origin:=monster_skill_origin(id)
			if origin.is_empty():continue
			var previous:=after
			after=mini(1000,after+1);count+=1
			if previous<900 and after>=900 and jobs[actor["job_id"]]["type"]=="human":forced=origin
		result.append({"actor":actor["id"],"name":actor["name"],"before":before/10.0,"after":after/10.0,"after_tenths":after,"battle_cost":battle_units/10.0,"skill_uses":count,"forced_job":forced,"crosses_irreversible":before<900 and after>=900})
	return result

func integrated_rule() -> Dictionary:
	if not IntegratedProgression.modern(_state):return {}
	var entry:=IntegratedCampaign.assignment(_integrated_site())
	for rule in catalog.integration["enemy_rules"]:
		if rule["id"]==entry.get("rule"):return rule.duplicate(true)
	return {}

func _integrated_site() -> String:
	return "world/"+str(_state["overworld"]["node"]) if world_exploration_active() else str(_state.get("expedition",{}).get("id",""))

func _integration_reward_kind() -> String:
	if _field_battle:return "normal"
	var enemies: Array=_battle_enemy_ids if _battle!=null else []
	if world_exploration_active():
		var event:=WorldExpedition.event_at(_state["overworld"])
		if _battle==null:enemies=event.get("enemies",[])
	elif _battle==null:
		var waves:=StoryCampaign.battle_waves(current_story_step())
		if story_wave_index()<waves.size():enemies=waves[story_wave_index()]
	for id in enemies:
		if id in ["gate_beast","elder_slime","ancient_shell","night_bat","core_wisp","flood_beast"]:return "boss"
	if world_exploration_active() or not _state.get("expedition",{}).is_empty():return "challenge"
	return "normal"

func _record_integrated_outcome() -> void:
	if _battle.effects.rules.is_empty():return
	var site:=_integrated_site()
	var assignment:=IntegratedCampaign.assignment(site)
	if assignment.is_empty():return
	var known_methods: Array=_state["integrated"]["outcomes"].get(site,{}).get("methods",[]).duplicate()
	for method in _battle.effects.methods:
		if method not in known_methods:known_methods.append(method)
	_state["integrated"]["outcomes"][site]={"rule":_battle.effects.rules.get("id",""),"methods":known_methods}
	if IntegratedCampaign.opens_route(known_methods) and not assignment["flag"].is_empty():_state["progress_flags"][assignment["flag"]]=true
	if IntegratedCampaign.grants_weapon(known_methods) and assignment["reward"] not in _state["integrated"]["armory"]:_state["integrated"]["armory"].append(assignment["reward"])
	if "field_break" in known_methods and site not in _state["integrated"]["claimed"]:
		_state["integrated"]["claimed"].append(site)
		_state["inventory"]["potion"]+=2

func integrated_observation() -> Dictionary:
	var rule:=integrated_rule()
	if rule.is_empty() or _battle!=null or is_returning_to_town():return {}
	var cell: Array=world_state()["player_cell"]
	var index:=0 if cell==[4,8] else (1 if cell==[18,8] else -1)
	if index<0:return {}
	return {"rule":rule["id"],"fact":index,"text":rule["facts"][index]}

func read_integrated_observation() -> Array:
	var clue:=integrated_observation()
	if clue.is_empty():return []
	var known: Dictionary=_state["integrated"]["knowledge"].get(clue["rule"],{"facts":[],"confirmed":false})
	if clue["fact"] not in known["facts"]:known["facts"].append(clue["fact"])
	_state["integrated"]["knowledge"][clue["rule"]]=known
	return [clue["text"]]


func mastery_forecast(field_battle: bool=false) -> Array[Dictionary]:
	var result: Array[Dictionary]=[]
	if not IntegratedProgression.modern(_state):return result
	var amount:=int(IntegratedProgression.reward("normal" if field_battle else _integration_reward_kind())["jp"])
	for actor in _state["party"]:
		var job: Dictionary=jobs[actor["job_id"]]
		if job["type"]!="monster" or job["id"] in actor["mastered_jobs"]:continue
		if int(actor["jp"].get(job["id"],0))+amount>=int(job["mastery_cost"]):
			result.append({"actor":actor["id"],"name":actor["name"],"job":job["name"],"job_id":job["id"],"jp":amount,"kind":"mastery","form":job["monster_form"]})
	return result
