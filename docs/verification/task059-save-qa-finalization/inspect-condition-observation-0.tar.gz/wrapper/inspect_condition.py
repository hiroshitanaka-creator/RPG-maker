from pathlib import Path
import argparse,hashlib,importlib.util,json,sys,time
ROOT=Path('/tmp/qa059/full');sys.path.insert(0,str(ROOT/'tools/fixtures/equipment-save-transaction-platform'))
spec=importlib.util.spec_from_file_location('d',ROOT/'tools/check_equipment_save_transaction_platform.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
for index in range(2):
 class Observed(d.Suite):
  def run(self,root,cfg,label,**kwargs):
   before={p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()} if cfg.get('operation')=='inspect' else None
   result=super().run(root,cfg,label,**kwargs)
   if before is not None:
    changes=[]
    for name,old in before.items():
     p=root/name;new=p.read_bytes() if p.exists() else None
     if old!=new:changes.append(dict(path=name,before_size=len(old),after_size=len(new) if new is not None else None,before_sha256=hashlib.sha256(old).hexdigest(),after_sha256=hashlib.sha256(new).hexdigest() if new is not None else None,before_text=old.decode(errors='replace')[:2000],after_text=new.decode(errors='replace')[:2000] if new is not None else None))
    d.write(self.output/'observed-files.json',dict(changes=changes,observed=len(before),note='元assertionを変えずinspect呼出し前後の既存file bytesを追加観測'))
   return result
 area=Path('/tmp/qa059/inspect-condition-'+str(index));s=Observed(argparse.Namespace(godot='/tmp/qa059/engine/Godot_v4.7.2-stable_linux.x86_64',fixture_root=area/'qa',output=area/'results'))
 s.seeds['typed']=Path('/tmp/qa059/astra-full-run/qa/seed-typed')
 try:
  row=s.run_case('inspect-prepared',s.expected['cases']['inspect-prepared']);print(index,row['checks'],flush=True)
 finally:s.restarts.close()
