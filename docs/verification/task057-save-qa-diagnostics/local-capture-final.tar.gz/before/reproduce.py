import importlib.util,json,time,sys
from pathlib import Path
from concurrent.futures import Future
spec=importlib.util.spec_from_file_location('before','/tmp/qa057/before.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
s=m.Suite.__new__(m.Suite);s.godot=Path('/tmp/qa057/fake-engine');s.output=Path('/tmp/qa057/repro');s.output.mkdir();s.deadline=time.monotonic()+35
root=Path('/tmp/qa057/repro-root');root.mkdir();start=time.monotonic()
try:s.run_restart_batch([(root,{'root':str(root),'operation':'resume'},Future())])
except Exception as e:row={'exception':type(e).__name__,'detail':str(e),'seconds':time.monotonic()-start,'logs':list(map(str,s.output.rglob('*.log'))),'execution':list(map(str,s.output.rglob('*execution.json')))}
Path('/tmp/qa057/repro.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
