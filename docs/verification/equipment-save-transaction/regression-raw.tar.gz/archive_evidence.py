from pathlib import Path
import tarfile,hashlib,json,shutil,os
qa=Path('/workspace/qa053');dest=Path('/workspace/RPG-maker/docs/verification/equipment-save-transaction');dest.mkdir(parents=True,exist_ok=True)
def archive(name,sources):
 out=dest/(name+'.tar.gz');members=[]
 with tarfile.open(out,'w:gz',compresslevel=6,dereference=False) as tar:
  for source in sources:
   paths=[source]+sorted(source.rglob('*')) if source.is_dir() else [source]
   for p in paths:
    rel=p.relative_to(qa).as_posix()
    if 'XDG_CACHE_HOME' in p.parts or '.godot' in p.parts:continue
    if p.is_symlink():
     raw=os.readlink(p).encode();kind='symlink'
    elif p.is_file():raw=p.read_bytes();kind='file'
    else:continue
    tar.add(p,arcname=rel,recursive=False)
    members.append({'path':rel,'kind':kind,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 (dest/(name+'-members.json')).write_text(json.dumps(members,ensure_ascii=False,indent=2)+'\n')
 print(name,len(members),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest(),flush=True)
 with tarfile.open(out) as tar:
  index={m.name:m for m in tar.getmembers()}
  for row in members:
   member=index[row['path']];raw=member.linkname.encode() if row['kind']=='symlink' else tar.extractfile(member).read()
   assert len(raw)==row['size'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 return {'archive':out.name,'size':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'members':len(members),'verified':True}
rows=[archive('fixed053-raw',[qa/'fixed-run',qa/'fixed-wrapper.log'])]
proto=[p for p in qa.iterdir() if (p.name.startswith('test') or p.name.startswith('final-precommit') or p.name in ['initial-validation-propagation','pre-final-validation.log','precommit-propagation.json','profile-trace.log','profile-source.gd','import-initial.log','import-s3.log','import-final-code.log','make_expected.py','smoke','smoke.py','excluded-generated'])]
rows.append(archive('development-raw',sorted(proto)))
(dest/'archives.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
for name in ['execution.json','commands.json']:
 shutil.copyfile(qa/'fixed-run'/name,dest/('fixed-'+name))
shutil.copyfile(qa/'fixed-run/results/summary.json',dest/'fixed-summary.json')
(dest/'code-fixed-sha.txt').write_text('75b6e350f3e52daeff16408f7d3154debe9a8ca4\n')
lines=['# 固定053 全ケース実測','', '| ID | 期待理由 | 実理由 | 条件 | 子exit | phase |','|---|---|---|---:|---|---|']
for p in sorted((qa/'fixed-run/results').glob('*/case.json')):
 row=json.loads(p.read_text()); actual=row['actual']; checks=row.get('checks',[]);commands=row.get('commands',[])
 lines.append('| '+p.parent.name+' | '+str(row['expected'].get('reason',''))+' | '+str(actual.get('reason_code',''))+' | '+str(len(checks))+' | '+','.join(str(c.get('exit_code')) for c in commands)+' | '+str(actual.get('phase',''))+' |')
(dest/'cases.md').write_text('\n'.join(lines)+'\n')
