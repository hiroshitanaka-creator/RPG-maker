import os, pathlib, subprocess, time, json, hashlib, sys
base=pathlib.Path('/workspace/qa053/regression');base.mkdir(exist_ok=True)
engine=pathlib.Path('/workspace/qa053/bin/Godot_v4.7.2-stable_linux.x86_64')
link=base/'godot'
if not link.exists():link.symlink_to(engine)
env=os.environ.copy();env['PATH']=str(base)+os.pathsep+env['PATH'];env['RPG_QA_SAVE_PREFIX']='053-regression';env['RPG_LEGACY_EQ_OUTPUT']=str(base/'legacy.json');env['EQUIPMENT_CODEC_EVIDENCE']=str(base/'codec')
for k in ['XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME']:
 p=base/k;p.mkdir(exist_ok=True);env[k]=str(p)
commands=[('R01-R08',[sys.executable,'tools/run_locked_checks.py'],900),('protected',[sys.executable,'tools/check_frozen_files.py'],30),('equipment',[str(engine),'--headless','--path','.','--script','res://tools/check_equipment_rules.gd'],240),('S1',[str(engine),'--headless','--path','.','--script','res://tools/check_equipment_save_migration.gd'],120),('S2',[str(engine),'--headless','--path','.','--script','res://tools/check_equipment_save_codec.gd'],120),('legacy',[str(engine),'--headless','--path','.','--script','res://tools/fixtures/equipment-save/legacy_equivalence.gd'],120),('assets',[sys.executable,'tools/validate_assets.py','--strict'],120)]
results=[]
for name,argv,budget in commands:
 start=time.monotonic();log=base/(name+'.log');timeout=False
 with log.open('wb') as f:
  try:p=subprocess.run(argv,cwd='/workspace/qa053/fixed053',env=env,stdout=f,stderr=subprocess.STDOUT,timeout=budget);code=p.returncode
  except subprocess.TimeoutExpired:code=-1;timeout=True
 row={'name':name,'argv':argv,'budget_seconds':budget,'seconds':time.monotonic()-start,'exit_code':code,'timed_out':timeout,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};results.append(row)
 (base/'commands.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(name,code,round(row['seconds'],3),flush=True)
 if code:sys.exit(1)
