from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,zipfile
w=Path('/workspace/task080');a=json.loads((w/'active-recheck.json').read_text());run=Path(a['directory']);out=Path(a['evidence']);repo=Path(a['repo']);source=Path('/workspace/RPG-maker')
chron=json.loads((out/'chronology.json').read_text());records=chron['records'];assert len(records)==17
assert chron['import_first'] and chron['import_finished_before_every_verification'] and chron['sequential_no_overlap'] and chron['locked_all_pass']
for x in records:
 assert x['started_at_utc']<x['ended_at_utc']
 assert hashlib.sha256((out/(x['name']+'.log')).read_bytes()).hexdigest()==x['log_sha256']
 assert x['exit_code']==(1 if x['name']=='05-assets-strict' else 0)
# 出所エラーが旧候補と同じ5件であることを文字列集合で照合する。
new_ng=[s.strip() for s in (out/'05-assets-strict.log').read_text().splitlines() if s.strip().startswith('NG ')]
old_ng=[s.strip() for s in (w/'evidence/assets-strict.log').read_text().splitlines() if s.strip().startswith('NG ')]
assert len(new_ng)==5 and new_ng==old_ng
tracked=json.loads((out/'candidate-all-tracked-sha256.json').read_text());mismatches=[]
for name,expected in tracked.items():
 for location in [repo,source]:
  if hashlib.sha256((location/name).read_bytes()).hexdigest()!=expected['sha256']:mismatches.append({'path':name,'location':str(location)})
assert not mismatches,mismatches
original=json.loads((w/'handoff.json').read_text());old_zip=Path(original['zip']);assert hashlib.sha256(old_zip.read_bytes()).hexdigest()==original['sha256']
post={'verified_at_utc':datetime.now(timezone.utc).isoformat(),'candidate_tree':chron['candidate_tree'],'candidate_tracked_files':len(tracked),'reconstructed_tracked_mismatches':mismatches,'original_candidate_tracked_mismatches':mismatches,'old_zip_unchanged':True,'old_zip_sha256':original['sha256'],'old_library_file_id':original['library_file_id'],'strict_errors_unchanged':new_ng,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'reconstructed_index_tree':subprocess.check_output(['git','write-tree'],cwd=repo,text=True).strip(),'reconstructed_untracked_generated':subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()}
assert post['reconstructed_index_tree']==chron['candidate_tree']
(out/'after-verification-preservation.json').write_text(json.dumps(post,ensure_ascii=False,indent=2)+'\n')
rows=[]
for name in ['inn','item_shop','weapon_shop','shrine','armor_shop']:
 d=json.loads((out/('render-'+name+'.json')).read_text());assert d['failed']==0
 differences=[c['detail'] for c in d['checks'] if c['label']=='家具の前後の遮蔽']
 rows.append({'room':name,'checks':len(d['checks']),'input_events':len(d['inputs']),'failed':d['failed'],'occlusion':differences})
summary={'rooms':rows,'checks':sum(x['checks'] for x in rows),'input_events':sum(x['input_events'] for x in rows),'locked':json.loads((out/'locked-results.json').read_text()),'strict_errors_unchanged':True,'import_started_at_utc':records[0]['started_at_utc'],'import_ended_at_utc':records[0]['ended_at_utc'],'first_check_started_at_utc':records[1]['started_at_utc'],'last_check_ended_at_utc':records[-1]['ended_at_utc']}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
shutil.copyfile(run/'driver.log',out/'driver.log');shutil.copyfile(w/'finalize_recheck.py',out/'finalize_recheck.py')
text='# 080 UTC時刻付き再検証・補足報告\n\n'
text+='基点 `'+original['base_sha']+'`、候補tree `'+chron['candidate_tree']+'`。新実装・仕様・台帳・画像・既存検査の変更はない。旧ZIP/Libraryを保持し、このZIPは追加証拠だけを保存する。GitHub操作・親台帳更新・PR49保留解除はしていない。\n\n'
text+='## import先行の実測\n\n'
text+='editor import: '+records[0]['started_at_utc']+' → '+records[0]['ended_at_utc']+'、exit0。最初の後続検査開始 '+records[1]['started_at_utc']+'。17実行すべてにUTC ISO8601開始/終了、コマンド、cwd、timeout、exit、単調時計の経過秒、ログSHA256を保存。chronology.jsonで全後続検査がimport終了後に開始し、各検査が逐次で重ならないことを照合した。時刻の後付けや旧ログの時刻推測ではない。\n\n'
text+='| 実行 | 開始 UTC | 終了 UTC | 上限秒 | exit |\n| --- | --- | --- | ---: | ---: |\n'
for x in records:text+='| '+x['name']+' | '+x['started_at_utc']+' | '+x['ended_at_utc']+' | '+str(x['timeout_seconds'])+' | '+str(x['exit_code'])+' |\n'
text+='\nXorgは描画用バックグラウンド設備で、import後に起動・5室の描画後に終了。xorg.execution.jsonのlifecycleはこの設備の記録であり、17件の検査ではない。\n\n'
text+='## 結果\n\n'
text+='5室の通常入力/描画は合計%d判定・%d入力イベント、失敗0。各室の背景/全床/入口往復/壁家具拒否/前後遮蔽/本番保存拒否/既存保存往復を元の検査器で再実行。追加Python検証・負例も成功。R-01〜R-08は元verify文字列と300秒の上限を維持し、元run_locked_checks.pyのjudge_outputで全PASS。保護26検査成功。素材strictは同じ5件のownerパス拒否でexit1のまま保持。\n\n'%(summary['checks'],summary['input_events'])
text+='## 全tree再構成と保全\n\n'
text+='別checkoutで基点の全7738 trackedファイルを実体展開し、全ファイルのGit blobと実bytesを照合。candidate.patchをgit apply --check --index後に適用し、git write-treeで旧候補treeと完全一致。候補の全7982 trackedファイルも実bytes照合。base-all-tracked-sha256.json / candidate-all-tracked-sha256.jsonに全パス・Git blob・mode・bytes・SHA256を収録。protected-26-base-candidate-sha256.jsonに保護26実ファイルの基点/候補/凍結SHAと一致判定を収録。検証終了後にも再構成checkoutと元作業領域の全7982対象bytes、候補index tree、旧ZIP SHAが不変であることを確認した。自動生成の未tracked UIDはafter-verification-preservation.jsonに分け、候補へ追加していない。\n\n'
text+='## 再現と残件\n\nprepare_recheck.py / timestamped_recheck.py / finalize_recheck.pyを同梱する。今回の絶対パスは各JSONに記録。別環境では作業/証拠保存先だけを対応させ、検査器・コマンド条件・時間上限を変えない。candidate.patchは旧ZIPのchanges.patchと同一SHA。SHA256SUMS.jsonは自身を除くZIP全entryを列挙し、CRCと全entry bytesを検査する。\n\n素材出所5件の限定検査変更はユーザー回答待ち。今回validate_assets.pyは無変更。旧coastal既知失敗は旧ZIPに原証拠があり、今回の追加依頼では再実行していない。正式保存・全CI・本番接続は未実行/未完了。\n'
(run/'REPORT.md').write_text(text)
manifest=[]
include=[run/'REPORT.md',run/'candidate.patch']+sorted(p for p in out.rglob('*') if p.is_file())
for p in include:manifest.append({'path':p.relative_to(run).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(run/'SHA256SUMS.json').write_text(json.dumps({'excluded_self':'SHA256SUMS.json','files':manifest},ensure_ascii=False,indent=2)+'\n')
zip_path=w/('task-080-timestamped-evidence-'+run.name.removeprefix('recheck-')+'.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in include+[run/'SHA256SUMS.json']:z.write(p,p.relative_to(run).as_posix())
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 for entry in manifest:assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256']
result={'zip':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'base_sha':original['base_sha'],'candidate_tree':chron['candidate_tree'],'implementation_changed':False,'old_zip_unchanged':True,'old_library_file_id':original['library_file_id'],'entries':len(manifest)+1,'checks':summary['checks'],'inputs':summary['input_events'],'import_started_at_utc':summary['import_started_at_utc'],'import_ended_at_utc':summary['import_ended_at_utc'],'first_check_started_at_utc':summary['first_check_started_at_utc'],'last_check_ended_at_utc':summary['last_check_ended_at_utc'],'report':str(run/'REPORT.md')}
(run/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
