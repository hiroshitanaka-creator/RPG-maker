"""080補足。候補を変更せず、既存コマンド・判定・予算をUTC時刻と共に再実行する。"""
from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,time,os,importlib.util,hashlib,shutil
utc=lambda:datetime.now(timezone.utc).isoformat(timespec='microseconds')
a=json.loads(Path('/workspace/task080/active-recheck.json').read_text());run=Path(a['directory']);out=Path(a['evidence']);repo=Path(a['repo'])
assert (out/'reconstruction.json').is_file()
env=os.environ.copy();env.update(PATH='/workspace/task080/bin:'+env['PATH'],XDG_DATA_HOME=str(run/'xdg/data'),XDG_CONFIG_HOME=str(run/'xdg/config'),XDG_CACHE_HOME=str(run/'xdg/cache'),RPG_QA_SAVE_PREFIX='task080_timed',ADOPTED_ROOM_OUTPUT=str(out),DISPLAY=':82')
records=[]
def execute(name,command,limit,extra=None,shell=False):
 start=utc();tick=time.monotonic();local=env.copy();local.update(extra or {})
 record={'sequence':len(records),'name':name,'started_at_utc':start,'command':command,'shell':shell,'cwd':str(repo),'timeout_seconds':limit,'environment_overrides':{k:local[k] for k in ['PATH','XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME','RPG_QA_SAVE_PREFIX','ADOPTED_ROOM_OUTPUT','DISPLAY']},'case_environment':extra or {},'status':'running'}
 with (out/(name+'.started.json')).open('x') as f:json.dump(record,f,ensure_ascii=False,indent=2)
 timed_out=False
 with (out/(name+'.log')).open('xb') as f:
  try:p=subprocess.run(command,cwd=repo,env=local,stdout=f,stderr=subprocess.STDOUT,timeout=limit,shell=shell);code=p.returncode
  except subprocess.TimeoutExpired:code=124;timed_out=True
 record.update(ended_at_utc=utc(),elapsed_seconds=time.monotonic()-tick,exit_code=code,timed_out=timed_out,status='timeout' if timed_out else 'executed',log_sha256=hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest())
 with (out/(name+'.execution.json')).open('x') as f:json.dump(record,f,ensure_ascii=False,indent=2)
 records.append(record);print(json.dumps(record,ensure_ascii=False),flush=True)
 return record
# 検査の第0実行を必ずeditor importとする。失敗した場合は成功として続行しない。
imp=execute('00-editor-import',['godot','--headless','--editor','--import','--quit'],600)
if imp['exit_code']!=0:raise SystemExit('import failed; later checks not executed')
structure=execute('01-python',['python3','tools/check_adopted_room_foundation.py','--output',str(out)],120)
if structure['exit_code']!=0:raise SystemExit('structure failed; later checks not executed')
# 描画設備の起動はimport後。ライフサイクルは検査コマンドとは別に記録する。
xargs=['Xorg',':82','-config','/etc/X11/xorg.conf','-noreset','-nolisten','tcp','-logfile',str(out/'xorg.log')]
shutil.copyfile('/etc/X11/xorg.conf',out/'xorg.conf')
xf=(out/'xorg-stdout.log').open('xb');xstart=utc();xp=subprocess.Popen(xargs,cwd=repo,env=env,stdout=xf,stderr=subprocess.STDOUT)
try:
 for attempt in range(50):
  if xp.poll() is not None:raise RuntimeError('Xorg exited before tests')
  if Path('/tmp/.X11-unix/X82').exists():break
  time.sleep(.1)
 else:raise RuntimeError('Xorg startup timeout')
 for index,name in enumerate(['inn','item_shop','weapon_shop','shrine','armor_shop']):
  execute('02-render-'+name,['godot','--display-driver','x11','--audio-driver','Dummy','--path','.','--script','res://tools/check_adopted_room_foundation.gd'],180,{'ADOPTED_ROOM_INDEX':str(index)})
finally:
 xp.terminate()
 xp.wait(timeout=30);xf.close()
 (out/'xorg.execution.json').write_text(json.dumps({'command':xargs,'cwd':str(repo),'started_at_utc':xstart,'ended_at_utc':utc(),'exit_code':xp.returncode,'status':'terminated_by_runner_after_render_tests','lifecycle':'background display server; startup readiness 5 seconds; shutdown wait 30 seconds'},indent=2)+'\n')
spec=importlib.util.spec_from_file_location('locked',repo/'tools/run_locked_checks.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
locked=[]
for req in json.loads((repo/'.scope-lock/spec.lock.json').read_text())['requirements']:
 record=execute('03-'+req['id'],req['verify'],300,shell=True)
 judged=module.judge_output(req['id'],req['verify'],record['exit_code'],(out/('03-'+req['id']+'.log')).read_text(),record['timed_out'])
 locked.append(judged)
(out/'locked-results.json').write_text(json.dumps(locked,ensure_ascii=False,indent=2)+'\n')
execute('04-frozen',['python3','tools/check_frozen_files.py'],60)
# 同じ5件の出所依存を隠さず、終了1を原記録する。
execute('05-assets-strict',['python3','tools/validate_assets.py','--strict'],120)
summary={'started_at_utc':records[0]['started_at_utc'],'ended_at_utc':utc(),'candidate_tree':'19f0ef9e08b546ad3b9d9143e5b6b97e59ba6d31','execution_count':len(records),'import_first':records[0]['name']=='00-editor-import','import_finished_before_every_verification':all(imp['ended_at_utc']<=x['started_at_utc'] for x in records[1:]),'sequential_no_overlap':all(x['ended_at_utc']<=y['started_at_utc'] for x,y in zip(records,records[1:])),'records':records,'locked_all_pass':len(locked)==8 and all(x['status']=='PASS' for x in locked)}
(out/'chronology.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
assert summary['import_first'] and summary['import_finished_before_every_verification'] and summary['sequential_no_overlap']
assert summary['locked_all_pass']
assert all(x['exit_code']==(1 if x['name']=='05-assets-strict' else 0) for x in records)
for name in ['inn','item_shop','weapon_shop','shrine','armor_shop']:
 data=json.loads((out/('render-'+name+'.json')).read_text());assert data['failed']==0
print('TIMESTAMPED_RECHECK: requested checks PASS; strict remains exit1',flush=True)
