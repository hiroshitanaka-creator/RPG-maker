from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,os
utc=lambda:datetime.now(timezone.utc).isoformat()
w=Path('/workspace/task080');source=Path('/workspace/RPG-maker');base='e677896d3e61b8fe8136ef60c5c76f41ad76701d';expected='19f0ef9e08b546ad3b9d9143e5b6b97e59ba6d31'
start=utc();stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');run=w/('recheck-'+stamp);run.mkdir();ev=run/'evidence';ev.mkdir();repo=run/'reconstructed'
(w/'active-recheck.json').write_text(json.dumps({'directory':str(run),'evidence':str(ev),'repo':str(repo)},indent=2)+'\n')
commands=[]
def cmd(args,cwd):
 record={'command':args,'cwd':str(cwd),'started_at_utc':utc()}
 p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);record.update(ended_at_utc=utc(),exit_code=p.returncode);commands.append(record)
 with (ev/'reconstruction.log').open('ab') as f:f.write(p.stdout)
 assert p.returncode==0,(args,p.stdout.decode(errors='replace'))
 return p.stdout
cmd(['git','clone','--shared','--no-checkout',str(source),str(repo)],w)
cmd(['git','checkout','--detach',base],repo)
def entries(ref):
 data=subprocess.check_output(['git','ls-tree','-r','-z',ref],cwd=repo);result={}
 for row in data.split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,kind,blob=meta.decode().split();assert kind=='blob';name=path.decode();p=repo/name;raw=p.read_bytes()
  original=subprocess.check_output(['git','cat-file','blob',blob],cwd=repo)
  assert raw==original,name
  result[name]={'mode':mode,'git_blob':blob,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 return result
baseline=entries(base)
(ev/'base-all-tracked-sha256.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2)+'\n')
patch=w/'delivery/changes.patch';patch_sha=hashlib.sha256(patch.read_bytes()).hexdigest()
cmd(['git','apply','--check','--index',str(patch)],repo)
cmd(['git','apply','--index',str(patch)],repo)
tree=cmd(['git','write-tree'],repo).decode().strip();assert tree==expected,(tree,expected)
candidate=entries(tree)
(ev/'candidate-all-tracked-sha256.json').write_text(json.dumps(candidate,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((repo/'.scope-lock/frozen-files.json').read_text());protected=[]
for entry in manifest['files']:
 name=entry['path'];b=baseline[name];c=candidate[name]
 protected.append({'path':name,'base_sha256':b['sha256'],'candidate_sha256':c['sha256'],'frozen_sha256':entry['sha256'],'base_candidate_match':b['sha256']==c['sha256'],'frozen_match':c['sha256']==entry['sha256']})
assert len(protected)==26 and all(x['base_candidate_match'] and x['frozen_match'] for x in protected)
(ev/'protected-26-base-candidate-sha256.json').write_text(json.dumps(protected,ensure_ascii=False,indent=2)+'\n')
old_zip=w/'task-080-adopted-room-walking-foundation.zip';old_hash=hashlib.sha256(old_zip.read_bytes()).hexdigest();assert old_hash=='b96acae544b2cd3a139f248e89f380aa720e666a27f0e38012195d4e8cf63e0c'
# 元作業領域が旧候補の全tracked bytesと同じことを保全確認。
assert all((source/name).read_bytes()==(repo/name).read_bytes() for name in candidate)
proof={'started_at_utc':start,'ended_at_utc':utc(),'base_sha':base,'expected_candidate_tree':expected,'reconstructed_candidate_tree':tree,'base_tracked_files':len(baseline),'candidate_tracked_files':len(candidate),'patch_sha256':patch_sha,'all_physical_files_match_git_blobs':True,'original_candidate_all_tracked_bytes_match':True,'old_zip_unchanged_sha256':old_hash,'commands':commands}
(ev/'reconstruction.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(proof,ensure_ascii=False),flush=True)
